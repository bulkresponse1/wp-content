<?php
/**
 * Woocommerce helper functions
 */

if (!function_exists('cyberstore_mikado_woocommerce_meta_box_functions')) {
    function cyberstore_mikado_woocommerce_meta_box_functions($post_types) {
        $post_types[] = 'product';

        return $post_types;
    }

    add_filter('cyberstore_mikado_meta_box_post_types_save', 'cyberstore_mikado_woocommerce_meta_box_functions');
}

if (!function_exists('cyberstore_mikado_woocommerce_add_social_share_option')) {
    function cyberstore_mikado_woocommerce_add_social_share_option($container) {
        if (cyberstore_mikado_is_woocommerce_installed()) {
            cyberstore_mikado_add_admin_field(
                array(
                    'type'          => 'yesno',
                    'name'          => 'enable_social_share_on_product',
                    'default_value' => 'no',
                    'label'         => esc_html__('Product', 'cyberstore'),
                    'description'   => esc_html__('Show Social Share for Product Items', 'cyberstore'),
                    'parent'        => $container
                )
            );
        }
    }

    add_action('cyberstore_mikado_post_types_social_share', 'cyberstore_mikado_woocommerce_add_social_share_option', 10, 1);
}

if (!function_exists('cyberstore_mikado_woocommerce_style_dynamics_deps')) {
    function cyberstore_mikado_woocommerce_style_dynamics_deps($deps) {
        $style_dynamic_deps_array = array();

        if (cyberstore_mikado_is_woocommerce_installed() && cyberstore_mikado_load_woo_assets()) {
            $style_dynamic_deps_array[] = 'cyberstore-mikado-woo';
            if (cyberstore_mikado_is_responsive_on()) {
                $style_dynamic_deps_array[] = 'cyberstore-mikado-woo-responsive';
            }
        }

        return array_merge($deps, $style_dynamic_deps_array);
    }

    add_filter('cyberstore_mikado_style_dynamic_deps', 'cyberstore_mikado_woocommerce_style_dynamics_deps');
}

if (!function_exists('cyberstore_mikado_get_woo_shortcode_module_template_part')) {
    /**
     * Loads module template part.
     *
     * @param string $template name of the template to load
     * @param string $module name of the module folder
     * @param string $slug
     * @param array $params array of parameters to pass to template
     * @param array $additional_params array of additional parameters to pass to template
     *
     * @return html
     * @see cyberstore_mikado_get_template_part()
     */
    function cyberstore_mikado_get_woo_shortcode_module_template_part($template, $module, $slug = '', $params = array(), $additional_params = array()) {

        //HTML Content from template
        $html = '';
        $template_path = 'framework/modules/woocommerce/shortcodes/' . $module;

        $temp = $template_path . '/' . $template;

        if (is_array($params) && count($params)) {
            extract($params);
        }

        if (is_array($additional_params) && count($additional_params)) {
            extract($additional_params);
        }

        $templates = array();

        if ($temp !== '') {
            if ($slug !== '') {
                $templates[] = "{$temp}-{$slug}.php";
            }

            $templates[] = $temp . '.php';
        }
        $located = cyberstore_mikado_find_template_path($templates);
        if ($located) {
            ob_start();
            include($located);
            $html = ob_get_clean();
        }

        return $html;
    }
}

if (!function_exists('cyberstore_mikado_is_woocommerce_page')) {
    /**
     * Function that checks if current page is woocommerce shop, product or product taxonomy
     * @return bool
     *
     * @see is_woocommerce()
     */
    function cyberstore_mikado_is_woocommerce_page() {
        if (function_exists('is_woocommerce') && is_woocommerce()) {
            return is_woocommerce();
        } elseif (function_exists('is_cart') && is_cart()) {
            return is_cart();
        } elseif (function_exists('is_checkout') && is_checkout()) {
            return is_checkout();
        } elseif (function_exists('is_account_page') && is_account_page()) {
            return is_account_page();
        }
    }
}

if (!function_exists('cyberstore_mikado_is_woocommerce_shop')) {
    /**
     * Function that checks if current page is shop or product page
     * @return bool
     *
     * @see is_shop()
     */
    function cyberstore_mikado_is_woocommerce_shop() {
        return function_exists('is_shop') && (is_shop() || is_product());
    }
}

if (!function_exists('cyberstore_mikado_get_woo_shop_page_id')) {
    /**
     * Function that returns shop page id that is set in WooCommerce settings page
     * @return int id of shop page
     */
    function cyberstore_mikado_get_woo_shop_page_id() {
        if (cyberstore_mikado_is_woocommerce_installed()) {
            //get shop page id from options table
            $shop_id = get_option('woocommerce_shop_page_id');
            $page_id = !empty($shop_id) ? $shop_id : '-1';

            return $page_id;
        }
    }
}

if (!function_exists('cyberstore_mikado_is_product_category')) {
    function cyberstore_mikado_is_product_category() {
        return function_exists('is_product_category') && is_product_category();
    }
}

if (!function_exists('cyberstore_mikado_is_product_tag')) {
    function cyberstore_mikado_is_product_tag() {
        return function_exists('is_product_tag') && is_product_tag();
    }
}

if (!function_exists('cyberstore_mikado_load_woo_assets')) {
    /**
     * Function that checks whether WooCommerce assets needs to be loaded.
     *
     * @see cyberstore_mikado_is_woocommerce_page()
     * @see cyberstore_mikado_has_woocommerce_shortcode()
     * @see cyberstore_mikado_has_woocommerce_widgets()
     * @return bool
     */
    function cyberstore_mikado_load_woo_assets() {
        return cyberstore_mikado_is_woocommerce_installed() && (cyberstore_mikado_is_woocommerce_page() || cyberstore_mikado_has_woocommerce_shortcode() || cyberstore_mikado_has_woocommerce_widgets());
    }
}

if (!function_exists('cyberstore_mikado_return_woocommerce_global_variable')) {
    function cyberstore_mikado_return_woocommerce_global_variable() {
        if (cyberstore_mikado_is_woocommerce_installed()) {
            global $product;

            return $product;
        }
    }
}

if (!function_exists('cyberstore_mikado_has_woocommerce_shortcode')) {
    /**
     * Function that checks if current page has at least one of WooCommerce shortcodes added
     * @return bool
     */
    function cyberstore_mikado_has_woocommerce_shortcode() {
        $woocommerce_shortcodes = array(
            'add_to_cart',
            'add_to_cart_url',
            'product_page',
            'product',
            'products',
            'product_categories',
            'product_category',
            'recent_products',
            'featured_products',
            'sale_products',
            'best_selling_products',
            'top_rated_products',
            'product_attribute',
            'related_products',
            'woocommerce_messages',
            'woocommerce_cart',
            'woocommerce_checkout',
            'woocommerce_order_tracking',
            'woocommerce_my_account',
            'woocommerce_edit_address',
            'woocommerce_change_password',
            'woocommerce_view_order',
            'woocommerce_pay',
            'woocommerce_thankyou',
            'mkd_product_search'
        );

        $woocommerce_shortcodes = apply_filters('cyberstore_mikado_woocommerce_shortcodes_list', $woocommerce_shortcodes);

        foreach ($woocommerce_shortcodes as $woocommerce_shortcode) {
            $has_shortcode = cyberstore_mikado_has_shortcode($woocommerce_shortcode);

            if ($has_shortcode) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('cyberstore_mikado_has_woocommerce_widgets')) {
    /**
     * Function that checks if current page has at least one of WooCommerce shortcodes added
     * @return bool
     */
    function cyberstore_mikado_has_woocommerce_widgets() {
        $widgets_array = array(
            'mkd_woocommerce_dropdown_cart',
            'mkd_woocommerce_product_categories_widget',
            'mkd_woocommerce_product_search_widget',
            'woocommerce_widget_cart',
            'woocommerce_layered_nav',
            'woocommerce_layered_nav_filters',
            'woocommerce_price_filter',
            'woocommerce_product_categories',
            'woocommerce_product_search',
            'woocommerce_product_tag_cloud',
            'woocommerce_products',
            'woocommerce_recent_reviews',
            'woocommerce_recently_viewed_products',
            'woocommerce_top_rated_products'
        );

        $widgets_array = apply_filters('cyberstore_mikado_woocommerce_widgets_list', $widgets_array);

        foreach ($widgets_array as $widget) {
            $active_widget = is_active_widget(false, false, $widget);

            if ($active_widget) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('cyberstore_mikado_accessories_tab')) {
    function cyberstore_mikado_accessories_tab($tabs) {

        $crosssellProductIds = get_post_meta(get_the_ID(), '_crosssell_ids');

        if (!empty($crosssellProductIds) && !empty($crosssellProductIds[0])) { //variable has the value of an empty array when cross-sells value is unset

            $tabs['accessories'] = array(
                'title'    => __('Accessories', 'cyberstore'),
                'priority' => 1,
                'callback' => 'cyberstore_mikado_woocommerce_product_accessories_tab',
            );

        }

        return $tabs;
    }
}

if (!function_exists('cyberstore_mikado_woocommerce_product_accessories_tab')) {

    /**
     * Output the accessories tab content.
     *
     * @subpackage    Product/Tabs
     */
    function cyberstore_mikado_woocommerce_product_accessories_tab() {
        cyberstore_mikado_get_module_template_part('templates/parts/accessories', 'woocommerce', '');
    }
}

/**
 * Loads more function for products.
 */
if (!function_exists('mkd_product_ajax_load_category')) {
    function mkd_product_ajax_load_category() {
        $shortcode_params = array();

        if (!empty($_POST)) {
            foreach ($_POST as $key => $value) {
                if ($key !== '') {
                    $addUnderscoreBeforeCapitalLetter = preg_replace('/([A-Z])/', '_$1', $key);
                    $setAllLettersToLowercase = strtolower($addUnderscoreBeforeCapitalLetter);

                    $shortcode_params[$setAllLettersToLowercase] = $value;
                }
            }
        }

        $html = '';

        $product_list = new \MikadoCore\CPT\Shortcodes\ProductList\ProductList();

        $query_array = $product_list->generateProductQueryArray($shortcode_params);
        $query_results = new \WP_Query($query_array);
        $shortcode_params['this_object'] = $product_list;

        if ($query_results->have_posts()): while ($query_results->have_posts()) : $query_results->the_post();
            $html .= cyberstore_mikado_get_woo_shortcode_module_template_part('templates/parts/info-' . $shortcode_params['layout'], 'product-list', '', $shortcode_params);
        endwhile;
        else:
            $html .= '<div class="mkd-item-space"><p class="mkd-no-posts">' . esc_html__('No products were found!', 'cyberstore') . '</p></div>';
        endif;
        wp_reset_postdata();

        $return_obj = array(
            'html' => $html,
        );

        echo json_encode($return_obj);
        exit;
    }

    add_action('wp_ajax_nopriv_mkd_product_ajax_load_category', 'mkd_product_ajax_load_category');
    add_action('wp_ajax_mkd_product_ajax_load_category', 'mkd_product_ajax_load_category');
}

/**
 * Loads more function for products.
 */
if (!function_exists('mkd_product_advanced_ajax_load_category')) {
    function mkd_product_advanced_ajax_load_category() {
        $shortcode_params = array();

        if (!empty($_POST)) {
            foreach ($_POST as $key => $value) {
                if ($key !== '') {
                    $addUnderscoreBeforeCapitalLetter = preg_replace('/([A-Z])/', '_$1', $key);
                    $setAllLettersToLowercase = strtolower($addUnderscoreBeforeCapitalLetter);

                    $shortcode_params[$setAllLettersToLowercase] = $value;
                }
            }
        }

        $html = '';

        $product_list = new \MikadoCore\CPT\Shortcodes\ProductListAdvanced\ProductListAdvanced();

        $query_array = $product_list->generateProductQueryArray($shortcode_params);
        $query_results = new \WP_Query($query_array);
        $shortcode_params['this_object'] = $product_list;

        if ($query_results->have_posts()): while ($query_results->have_posts()) : $query_results->the_post();
            $advanced_size_meta = $shortcode_params['type'] == 'masonry' ? get_post_meta(get_the_ID(), 'mkd_product_advanced_list_size', true) : 'left';
            $advanced_size_meta = !empty($advanced_size_meta) ? $advanced_size_meta : 'left';
            $html .= cyberstore_mikado_get_woo_shortcode_module_template_part('templates/parts/advanced-list-' . $advanced_size_meta, 'product-list-advanced', '', $shortcode_params);
        endwhile;
        else:
            $html .= '<div class="mkd-item-space"><p class="mkd-no-posts">' . esc_html__('No products were found!', 'cyberstore') . '</p></div>';
        endif;
        wp_reset_postdata();

        $return_obj = array(
            'html' => $html,
        );

        echo json_encode($return_obj);
        exit;
    }

    add_action('wp_ajax_nopriv_mkd_product_advanced_ajax_load_category', 'mkd_product_advanced_ajax_load_category');
    add_action('wp_ajax_mkd_product_advanced_ajax_load_category', 'mkd_product_advanced_ajax_load_category');
}


if (!function_exists('cyberstore_mikado_woocommerce_add_multiple_products_to_cart')) {

    function cyberstore_mikado_woocommerce_add_multiple_products_to_cart($url = false) {
        // Make sure WC is installed, and add-to-cart qauery arg exists, and contains at least one comma.
        if (!class_exists('WC_Form_Handler') || empty($_REQUEST['add-to-cart']) || empty($_REQUEST['mkd-multi-add'])) {
            return;
        }

        // Remove WooCommerce's hook, as it's useless (doesn't handle multiple products).
        remove_action('wp_loaded', array('WC_Form_Handler', 'add_to_cart_action'), 20);

        $product_ids = $_REQUEST['add-to-cart'];

        foreach ($product_ids as $key => $value) {
            if ($value <= 0) {
                unset($product_ids[$key]);
            }
        }

        //Count product ids after removing empty values
        $count = count($product_ids);
        $number = 0;

        foreach ($product_ids as $key => $value) {
            // Check for quantities defined in curie notation (<product_id>:<product_quantity>)
            // https://dsgnwrks.pro/snippets/woocommerce-allow-adding-multiple-products-to-the-cart-via-the-add-to-cart-query-string/#comment-12236

            $product_id = $key;
            $_REQUEST['quantity'] = $value;

            if (++$number === $count) {
                // Ok, final item, let's send it back to woocommerce's add_to_cart_action method for handling.
                $_REQUEST['add-to-cart'] = $product_id;

                return WC_Form_Handler::add_to_cart_action($url);
            }

            $product_id = apply_filters('woocommerce_add_to_cart_product_id', absint($product_id));
            $was_added_to_cart = false;
            $adding_to_cart = wc_get_product($product_id);

            if (!$adding_to_cart) {
                continue;
            }

            $add_to_cart_handler = apply_filters('woocommerce_add_to_cart_handler', $adding_to_cart->get_type(), $adding_to_cart);

            // Variable product handling
            if ('variable' === $add_to_cart_handler) {
                cyberstore_mikado_restore_default_private_method('WC_Form_Handler', 'add_to_cart_handler_variable', $product_id);

                // Grouped Products
            } elseif ('grouped' === $add_to_cart_handler) {
                cyberstore_mikado_restore_default_private_method('WC_Form_Handler', 'add_to_cart_handler_grouped', $product_id);

                // Custom Handler
            } elseif (has_action('woocommerce_add_to_cart_handler_' . $add_to_cart_handler)) {
                do_action('woocommerce_add_to_cart_handler_' . $add_to_cart_handler, $url);

                // Simple Products
            } else {
                cyberstore_mikado_restore_default_private_method('WC_Form_Handler', 'add_to_cart_handler_simple', $product_id);
            }
        }
    }

    // Fire before the WC_Form_Handler::add_to_cart_action callback.
    add_action('wp_loaded', 'cyberstore_mikado_woocommerce_add_multiple_products_to_cart', 15);
}


if (!function_exists('cyberstore_mikado_restore_default_private_method')) {
    /**
     * Invoke class private method
     *
     * @since   0.1.0
     *
     * @param   string $class_name
     * @param   string $methodName
     *
     * @return  mixed
     *
     * @throws Exception
     */
    function cyberstore_mikado_restore_default_private_method($class_name, $methodName) {
        if (version_compare(phpversion(), '5.3', '<')) {
            throw new Exception('PHP version does not support ReflectionClass::setAccessible()', __LINE__);
        }

        $args = func_get_args();
        unset($args[0], $args[1]);
        $reflection = new ReflectionClass($class_name);
        $method = $reflection->getMethod($methodName);
        $method->setAccessible(true);

        $args = array_merge(array($class_name), $args);
        return call_user_func_array(array($method, 'invoke'), $args);
    }
}

function mkd_fn_yith_woocompare_actions_to_check_frontend() {
    return true;
}

if (!function_exists('cyberstore_mikado_woocommerce_price_html')) {
    function cyberstore_mikado_woocommerce_price_html($price, $product) {
        return preg_replace('@(<del>.*?</del>).*?(<ins>.*?</ins>)@misx', '$2 $1', $price);
    }
}

if ( ! function_exists( 'cyberstore_mikado_woocommerce_template_title_min_height' ) ) {

    function cyberstore_mikado_woocommerce_template_title_min_height() {
        $item_styles      = array();
        $title_min_height = cyberstore_mikado_options()->getOptionValue('mkd_products_title_min_height');

        if ( ! empty( $title_min_height ) ) {
            $item_styles['min-height'] = $title_min_height;
        }

        echo cyberstore_mikado_dynamic_css( 'ul.products>.product .mkd-products-inner .mkd-product-list-title', $item_styles );
    }

    add_action( 'cyberstore_mikado_style_dynamic', 'cyberstore_mikado_woocommerce_template_title_min_height' );
}