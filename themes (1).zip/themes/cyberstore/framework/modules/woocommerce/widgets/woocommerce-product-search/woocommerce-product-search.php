<?php

if ( class_exists( 'CyberstoreMikadoWidget' ) ) {
	class CyberstoreMikadoWooCommerceProductSearchWidget extends CyberstoreMikadoWidget {
		public function __construct() {
			parent::__construct(
				'mkd_woocommerce_product_search_widget',
				esc_html__( 'Mikado WooCommerce Product Search', 'cyberstore' ),
				array( 'description' => esc_html__( '', 'cyberstore' ) )
			);

			$this->setParams();
		}

		protected function setParams() {

			$this->params = array();
		}

		public function widget( $args, $instance ) {
			echo do_shortcode( '[mkd_product_search widget="yes"]' );
		}
	}
}