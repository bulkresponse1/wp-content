<?php

if ( ! function_exists( 'cyberstore_mikado_register_woocommerce_product_categories_widget' ) ) {
	/**
	 * Function that register image gallery widget
	 */
	function cyberstore_mikado_register_woocommerce_product_categories_widget( $widgets ) {
		$widgets[] = 'CyberstoreMikadoWooCommerceProductCategoriesWidget';
		
		return $widgets;
	}
	
	add_filter( 'cyberstore_mikado_register_widgets', 'cyberstore_mikado_register_woocommerce_product_categories_widget' );
}