<?php

if ( class_exists( 'CyberstoreMikadoWidget' ) ) {
	class CyberstoreMikadoWooCommerceProductCategoriesWidget extends CyberstoreMikadoWidget {
		public function __construct() {
			parent::__construct(
				'mkd_woocommerce_product_categories_widget',
				esc_html__( 'Mikado WooCommerce Product Categories', 'cyberstore' ),
				array( 'description' => esc_html__( '', 'cyberstore' ) )
			);

			$this->setParams();
		}

		protected function setParams() {

			$this->params = array(
				array(
					'type'        => 'textfield',
					'name'        => 'slugs',
					'title'       => esc_html__( 'Categories slugs', 'cyberstore' ),
					'description' => esc_html__( 'Add category slugs separated with comma', 'cyberstore' )
				)
			);
		}

		public function widget( $args, $instance ) {
			if ( $instance['slugs'] !== '' ) {
				$slugs = explode( ',', $instance['slugs'] );
			} else {
				$slugs = array();
			}

			$product_categories = get_terms( array(
				'taxonomy' => 'product_cat',
				'slug'     => $slugs
			) );

			?>

            <div class="widget mkd-product-categories-widget">
                <div class="mkd-product-categories-holder clearfix">
					<?php

					foreach ( $product_categories as $product_category ) {
						$id           = $product_category->term_id;
						$cat_thumb_id = get_term_meta( $id, 'thumbnail_id', true );
						$cat_thumb    = wp_get_attachment_image( $cat_thumb_id );
						$cat_name     = $product_category->name;
						?>

                        <div class="mkd-product-category mkd-cat-id-<?php echo esc_attr( $id ); ?>">
                            <div class="mkd-product-category-inner">
								<?php
								if ( ! empty( $cat_thumb ) ) {
									echo cyberstore_mikado_get_module_part( $cat_thumb );
								} else {
									?>

                                    <img src="<?php echo esc_url( wc_placeholder_img_src() ); ?>"/>

								<?php } ?>
                                <div class="mkd-product-cat-name-holder">
                                    <div class="mkd-product-cat-name-holder-inner">
                                <span class="mkd-product-category-name">
                                    <?php echo esc_html( $cat_name ); ?>
                                </span>
                                    </div>
                                </div>
                                <a class="mkd-cat-link" itemprop="url" href="<?php echo get_category_link( $id ); ?>"
                                   title="<?php echo esc_attr( $cat_name ); ?>"></a>
                            </div>
                        </div>
						<?php
					}
					?>
                </div>
            </div>

			<?php
		}
	}
}