<?php

$rating_enabled = false;
if (get_option( 'woocommerce_enable_review_rating' ) !== 'no') {
$rating_enabled = true;
$average = $product->get_average_rating();

$rating_html = wc_get_rating_html( $average );

?>

    <?php if ($rating_html !== '') { ?>
        <div class="mkd-pli-rating-holder">
            <div class="mkd-pli-rating"
                 title="<?php sprintf(esc_attr_e("Rated %s out of 5", "cyberstore"), $average); ?>">
                <span style="width: <?php echo esc_attr( ( $average / 5 ) * 100 ) . '%'; ?>"></span>
            </div>
        </div>
    <?php } ?>
<?php } ?>
