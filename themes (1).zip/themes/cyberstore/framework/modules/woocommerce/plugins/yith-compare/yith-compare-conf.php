<?php
if (cyberstore_mikado_is_yith_compare_installed()) {

//YITH compare link position
    global $yith_woocompare;
    remove_action('woocommerce_after_shop_loop_item', array($yith_woocompare->obj, 'add_compare_link'), 20);

    add_action('woocommerce_before_shop_loop_item', 'cyberstore_mikado_woocommerce_compare_shortcode', 4);

}

