<a class="mkd-pli-link" itemprop="url"
   href="<?php the_permalink($product_id); ?>"
   title="<?php echo get_the_title($product_id); ?>">
</a>