<?php

if (!function_exists('cyberstore_mikado_is_yith_compare_installed')) {
    function cyberstore_mikado_is_yith_compare_installed() {
        return defined('YITH_WOOCOMPARE');
    }
}

if (!function_exists('cyberstore_mikado_woocommerce_compare_shortcode')) {
    function cyberstore_mikado_woocommerce_compare_shortcode() {
        if (cyberstore_mikado_is_yith_compare_installed()) {
            echo do_shortcode('[yith_compare_button]');
        }
    }
}

if (!function_exists('cyberstore_mikado_yith_compare_popup_style')) {
    function cyberstore_mikado_yith_compare_popup_style() {
        $disable_popup_styles = cyberstore_mikado_options()->getOptionValue('mkd_products_list_disable_compare_popup_styles');

        if ($disable_popup_styles === 'yes') {
            print '<link rel="stylesheet" href="' . MIKADO_ASSETS_ROOT . '/css/elegant-icons/style.min.css' . '" type="text/css" />';
            print '<link rel="stylesheet" href="' . MIKADO_ASSETS_ROOT . '/css/dripicons/dripicons.css' . '" type="text/css" />';
            print '<link rel="stylesheet" href="' . MIKADO_ASSETS_ROOT . '/css/woocommerce.min.css' . '" type="text/css" />';
            print '<link rel="stylesheet" href="' . MIKADO_ASSETS_ROOT . '/css/woocommerce-responsive.min.css' . '" type="text/css" />';
            print '<script href="' . MIKADO_ASSETS_ROOT . '/js/modules.min.js' . '" type="text/javascript" /></script>';
        }
    }


    add_action('yith_woocompare_popup_head', 'cyberstore_mikado_yith_compare_popup_style');
}

if (!function_exists('cyberstore_mikado_yith_compare_popup_class')) {
    function cyberstore_mikado_yith_compare_popup_class($classes) {
        $disable_popup_styles = cyberstore_mikado_options()->getOptionValue('mkd_products_list_disable_compare_popup_styles');

        if ($disable_popup_styles === 'yes') {
            $classes[] = 'mkd-popup-compare';
        }

        return $classes;
    }

    add_filter('body_class', 'cyberstore_mikado_yith_compare_popup_class');
}

if (!function_exists('cyberstore_mikado_yith_compare_popup_layout')) {
    function cyberstore_mikado_yith_compare_popup_layout() {
        $disable_popup_styles = cyberstore_mikado_options()->getOptionValue('mkd_products_list_disable_compare_popup_styles');
        $index = 0;
        if ($disable_popup_styles === 'yes') {


            global $yith_woocompare;
            $products = $yith_woocompare->obj->get_products_list(); ?>

            <div class="mkd-pl-holder mkd-pli-separator-layout mkd-standard-layout mkd-pli-standard-excerpt mkd-large-space mkd-three-columns">

                <div class="mkd-pl-outer-popup mkd-outer-space clearfix">

                    <?php if (!empty($products)) {

                        foreach ($products as $product_id => $product) { ?>
                            <?php
                            $params['product_id'] = $product_id;
                            $params['product'] = $product;



                            $itemClasses = '';

                            if (!$product->is_in_stock()) {
                                $itemClasses = 'mkd-pli-out-of-stock-holder';
                            }

                            ?>




                            <div class="mkd-pli-popup mkd-item-space <?php echo esc_attr($itemClasses); ?>">

                                <div class="mkd-pli-holder-popup">
                                    <?php echo cyberstore_mikado_get_module_template_part('yith-compare/templates/category', 'woocommerce/plugins', '', $params); ?>

                                    <div class="mkd-pli-inner">
                                        <div class="mkd-pli-image-popup">
                                            <?php echo cyberstore_mikado_get_module_template_part('yith-compare/templates/labels', 'woocommerce/plugins', '', $params); ?>
                                            <?php echo cyberstore_mikado_get_module_template_part('yith-compare/templates/image', 'woocommerce/plugins', '', $params); ?>
                                        </div>
                                        <?php echo cyberstore_mikado_get_module_template_part('yith-compare/templates/link', 'woocommerce/plugins', '', $params); ?>
                                    </div>
                                    <div class="mkd-pli-text-wrapper-popup">

                                        <?php echo cyberstore_mikado_get_module_template_part('yith-compare/templates/rating', 'woocommerce/plugins', '', $params); ?>

                                        <div class="mkd-pli-text-left-holder-popup">

                                            <div itemprop="description" class="mkd-pli-excerpt-popup">
                                                <?php echo cyberstore_mikado_get_module_template_part('yith-compare/templates/excerpt', 'woocommerce/plugins', '', $params); ?>
                                            </div>

                                            <?php echo cyberstore_mikado_get_module_template_part('yith-compare/templates/sku', 'woocommerce/plugins', '', $params); ?>

                                            <?php echo cyberstore_mikado_get_module_template_part('yith-compare/templates/title', 'woocommerce/plugins', '', $params); ?>

                                            <?php echo cyberstore_mikado_get_module_template_part('yith-compare/templates/price', 'woocommerce/plugins', '', $params); ?>
                                        </div>

                                        <?php echo cyberstore_mikado_get_module_template_part('yith-compare/templates/add-to-cart', 'woocommerce/plugins', '', $params); ?>

                                        <?php $product_class = 'product_' . $product_id ?>


                                    </div>
                                    <div class="remove">
                                        <div class="<?php echo esc_attr($product_class); ?> remove-popup-inner">
                                            <a href="<?php echo add_query_arg( '', '', $yith_woocompare->obj->remove_product_url( $product_id ) ) ?>" data-product_id="<?php echo esc_attr($product_id); ?>"><span class="remove  mkd-icon-dripicons dripicon dripicons-cross"></span><?php esc_html_e( 'Remove Product', 'cyberstore' ) ?> </a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php }

                    } ?>

                </div>

            </div>

        <?php }
    }

    add_action('yith_woocompare_before_main_table', 'cyberstore_mikado_yith_compare_popup_layout');

}