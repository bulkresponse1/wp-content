<?php $product_categories = wc_get_product_category_list($product_id, ', ');

if (!empty($product_categories)) { ?>
    <p class="mkd-pli-category-popup"><?php echo wp_kses_post($product_categories); ?></p>
<?php } ?>