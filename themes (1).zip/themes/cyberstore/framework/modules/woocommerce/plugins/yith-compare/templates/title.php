<h5 itemprop="name" class="entry-title mkd-pli-title">
    <a itemprop="url"
       href="<?php the_permalink($product_id); ?>"><?php echo esc_html($product->get_title()); ?></a>
</h5>