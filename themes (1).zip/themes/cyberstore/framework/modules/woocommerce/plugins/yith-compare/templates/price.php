<?php if ($price_html = $product->get_price_html()) { ?>
    <div class="mkd-pli-price"><?php echo wp_kses_post($price_html); ?></div>
<?php } ?>