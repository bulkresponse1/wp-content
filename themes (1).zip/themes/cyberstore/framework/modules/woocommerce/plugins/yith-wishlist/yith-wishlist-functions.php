<?php

if(!function_exists('cyberstore_mikado_is_yith_wishlist_installed')) {
    function cyberstore_mikado_is_yith_wishlist_installed() {
        return defined('YITH_WCWL');
    }
}

if(!function_exists('cyberstore_mikado_woocommerce_wishlist_shortcode')) {
    function cyberstore_mikado_woocommerce_wishlist_shortcode() {

        if(cyberstore_mikado_is_yith_wishlist_installed()) {
            echo do_shortcode('[yith_wcwl_add_to_wishlist]');
        }
    }
}

if ( ! function_exists( 'cyberstore_mikado_register_woocommerce_wishlist_widget' ) && cyberstore_mikado_is_yith_wishlist_installed() ) {
	/**
	 * Function that register image gallery widget
	 */
	function cyberstore_mikado_register_woocommerce_wishlist_widget( $widgets ) {
		$widgets[] = 'CyberstoreMikadoYithWishlist';

		return $widgets;
	}

	add_filter( 'cyberstore_mikado_register_widgets', 'cyberstore_mikado_register_woocommerce_wishlist_widget' );
}