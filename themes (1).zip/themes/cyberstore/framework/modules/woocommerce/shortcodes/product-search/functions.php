<?php

if (!function_exists('cyberstore_mikado_add_product_search_shortcode')) {
    function cyberstore_mikado_add_product_search_shortcode($shortcodes_class_name) {
        $shortcodes = array(
            'MikadoCore\CPT\Shortcodes\ProductSearch\ProductSearch',
        );

        $shortcodes_class_name = array_merge($shortcodes_class_name, $shortcodes);

        return $shortcodes_class_name;
    }

    if (cyberstore_mikado_core_plugin_installed()) {
        add_filter('mkd_core_filter_add_vc_shortcode', 'cyberstore_mikado_add_product_search_shortcode');
    }
}

if (!function_exists('cyberstore_mikado_add_product_search_into_shortcodes_list')) {
    function cyberstore_mikado_add_product_search_into_shortcodes_list($woocommerce_shortcodes) {
        $woocommerce_shortcodes[] = 'mkd_product_search';

        return $woocommerce_shortcodes;
    }

    add_filter('cyberstore_mikado_woocommerce_shortcodes_list', 'cyberstore_mikado_add_product_search_into_shortcodes_list');
}

if (!function_exists('cyberstore_mikado_localize_product_list')) {
    function cyberstore_mikado_localize_product_list() {

        $product_list = get_posts(array(
            'post_status'    => 'publish',
            'post_type'      => 'product',
            'posts_per_page' => -1
        ));

        $product_array = array();

        if (is_array($product_list) && count($product_list)) {
            $product_atts = array();

            foreach ($product_list as $product) {

                $_pf = new WC_Product_Factory();
                $_product = $_pf->get_product($product->ID);

                //product categories
                $product_cats = get_the_terms($product->ID, 'product_cat');
                $product_cat_slugs = array();

                if(!empty($product_cats)) {
                    foreach ($product_cats as $product_cat) {
                        $product_cat_slugs[] = $product_cat->slug;
                    }
                }

                //product thumbnail link
                $product_thumb = get_the_post_thumbnail_url($product->ID);

                //product price
                $product_price = $_product->get_price_html();


                //set JS global variable attributes
                $product_atts['ID'] = $product->ID;
                $product_atts['post_title'] = $product->post_title;
                $product_atts['thumb'] = $product_thumb;
                $product_atts['price'] = $product_price;
                $product_atts['product_cat'] = $product_cat_slugs;


                $product_array[] = $product_atts;
            }
        }

        wp_localize_script('cyberstore-mikado-modules', 'mkdProductList', array(
            'products'       => $product_array,
        ));
    }

    add_action('wp_enqueue_scripts', 'cyberstore_mikado_localize_product_list', 11);
}