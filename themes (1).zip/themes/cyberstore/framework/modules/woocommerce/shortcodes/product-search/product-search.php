<?php
namespace MikadoCore\CPT\Shortcodes\ProductSearch;

use MikadoCore\Lib;

class ProductSearch implements Lib\ShortcodeInterface
{
    private $base;

    function __construct() {
        $this->base = 'mkd_product_search';

        add_action('vc_before_init', array($this, 'vcMap'));
    }

    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        if (function_exists('vc_map')) {
            vc_map(
                array(
                    'name'                      => esc_html__('Mikado Product Search', 'cyberstore'),
                    'base'                      => $this->getBase(),
                    'category'                  => esc_html__('by MIKADO', 'cyberstore'),
                    'icon'                      => 'icon-wpb-product-search extended-custom-icon',
                    'allowed_container_element' => 'vc_row',
                    'params'                    => array()
                )
            );
        }
    }

    public function render($atts, $content = null) {
        $args = array(
            'widget' => 'no'
        );

        $params = shortcode_atts($args, $atts);

        $params['categories'] = $this->getCategories();

        $params['classes'] = $this->getClasses($params);

        $html = cyberstore_mikado_get_woo_shortcode_module_template_part('templates/product-search', 'product-search', '', $params);

        return $html;
    }

    private function getCategories() {

        $categories = get_terms(array(
            'taxonomy' => 'product_cat',
        ));

        return $categories;
    }

    private function getClasses($params) {
        $classes = array();

        $classes['mkd-product-search-holder'] = array('mkd-product-search-holder');

        if ($params['widget'] == 'yes') {
            $classes['mkd-product-search-holder'][] = 'widget';
        }

        return $classes;
    }

}