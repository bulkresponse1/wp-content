<?php if ($show_category_filter == 'yes') { ?>
    <div class="mkd-pl-categories">
        <ul>
            <?php echo cyberstore_mikado_get_module_part($categories_filter_list); ?>
        </ul>
    </div>
<?php } ?>