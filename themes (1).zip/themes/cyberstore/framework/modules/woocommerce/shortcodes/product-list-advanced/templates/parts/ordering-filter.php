<?php if ($show_ordering_filter == 'yes') { ?>
    <div class="mkd-pl-ordering-outer">

        <h5><?php esc_html_e('Filter', 'cyberstore'); ?></h5>

        <div class="mkd-pl-ordering">
            <div>
                <h5><?php esc_html_e('Sort By', 'cyberstore'); ?></h5>
                <ul>
                    <?php echo cyberstore_mikado_get_module_part($ordering_filter_list); ?>
                </ul>
            </div>
            <div>
                <h5><?php esc_html_e('Price Range', 'cyberstore'); ?></h5>
                <ul class="mkd-pl-ordering-price">
                    <?php echo cyberstore_mikado_get_module_part($pricing_filter_list); ?>
                </ul>
            </div>
        </div>
    </div>
<?php } ?>