<?php

namespace MikadoCore\CPT\Shortcodes\ProductListSimple;

use MikadoCore\Lib;

class ProductListSimple implements Lib\ShortcodeInterface
{
    private $base;

    function __construct() {
        $this->base = 'mkd_product_list_simple';

        add_action('vc_before_init', array($this, 'vcMap'));
    }

    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        if (function_exists('vc_map')) {
            vc_map(
                array(
                    'name'                      => esc_html__('Mikado Product List - Simple', 'cyberstore'),
                    'base'                      => $this->base,
                    'icon'                      => 'icon-wpb-product-list-simple extended-custom-icon',
                    'category'                  => esc_html__('by MIKADO', 'cyberstore'),
                    'allowed_container_element' => 'vc_row',
                    'params'                    => array(
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'type',
                            'heading'     => esc_html__('Type', 'cyberstore'),
                            'value'       => array(
                                esc_html__('Latest', 'cyberstore')       => 'latest',
                                esc_html__('Best Sellers', 'cyberstore') => 'best-sellers',
                                esc_html__('Featured', 'cyberstore')     => 'featured'
                            ),
                            'save_always' => true
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'number',
                            'heading'     => esc_html__('Number of Products', 'cyberstore'),
                            'description' => esc_html__('Number of products to show (default value is 4)', 'cyberstore')
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'orderby',
                            'heading'     => esc_html__('Order By', 'cyberstore'),
                            'value'       => array_flip(cyberstore_mikado_get_query_order_by_array()),
                            'save_always' => true,
                            'dependency'  => array('element' => 'type', 'value' => array('featured'))
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'sort_order',
                            'heading'     => esc_html__('Order', 'cyberstore'),
                            'value'       => array_flip(cyberstore_mikado_get_query_order_array()),
                            'save_always' => true,
                            'dependency'  => array('element' => 'type', 'value' => array('featured'))
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'display_title',
                            'heading'    => esc_html__('Display Title', 'cyberstore'),
                            'value'      => array_flip(cyberstore_mikado_get_yes_no_select_array(false, true))
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'title_tag',
                            'heading'     => esc_html__('Title Tag', 'cyberstore'),
                            'value'       => array_flip(cyberstore_mikado_get_title_tag(true)),
                            'save_always' => true,
                            'dependency'  => array('element' => 'display_title', 'value' => array('yes'))
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'title_transform',
                            'heading'     => esc_html__('Title Text Transform', 'cyberstore'),
                            'value'       => array_flip(cyberstore_mikado_get_text_transform_array(true)),
                            'save_always' => true,
                            'dependency'  => array('element' => 'display_title', 'value' => array('yes'))
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'display_rating',
                            'heading'    => esc_html__('Display Rating', 'cyberstore'),
                            'value'      => array_flip(cyberstore_mikado_get_yes_no_select_array(false))
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'display_price',
                            'heading'    => esc_html__('Display Price', 'cyberstore'),
                            'value'      => array_flip(cyberstore_mikado_get_yes_no_select_array(false, true))
                        )
                    )
                )
            );
        }
    }

    public function render($atts, $content = null) {
        $default_atts = array(
            'type'            => 'latest',
            'number'          => '4',
            'orderby'        => 'title',
            'sort_order'      => 'ASC',
            'display_title'   => 'yes',
            'title_tag'       => 'h6',
            'title_transform' => 'uppercase',
            'display_price'   => 'yes',
            'display_rating'  => 'no'
        );
        $params = shortcode_atts($default_atts, $atts);

        $params['holder_classes'] = $this->getHolderClasses($params);
        $params['class_name'] = 'pls';

        $params['title_tag'] = !empty($params['title_tag']) ? $params['title_tag'] : $default_atts['title_tag'];
        $params['title_styles'] = $this->getTitleStyles($params);

        $queryArray = $this->generateProductQueryArray($params);
        $query_result = new \WP_Query($queryArray);
        $params['query_result'] = $query_result;

        $html = cyberstore_mikado_get_woo_shortcode_module_template_part('templates/product-list-template', 'product-list-simple', '', $params);

        return $html;
    }

    private function getHolderClasses($params) {
        $holderClasses = '';
        $productListType = $params['type'];

        switch ($productListType) {
            case 'latest':
                $holderClasses = 'mkd-pls-latest';
                break;
            case 'best-sellers':
                $holderClasses = 'mkd-pls-best-sellers';
                break;
            case 'featured':
                $holderClasses = 'mkd-pls-featured';
                break;
            default:
                $holderClasses = 'mkd-pls-latest';
                break;
        }

        return $holderClasses;
    }

    private function generateProductQueryArray($params) {
        switch ($params['type']) {
            case 'latest':
                $args = array(
                    'post_status'    => 'publish',
                    'post_type'      => 'product',
                    'posts_per_page' => $params['number'],
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                    'no_found_rows'  => 1,
                    'post__in'       => array_merge(array(0), wc_get_product_ids_on_sale())
                );
                break;
            case 'best-sellers':
                $args = array(
                    'post_status'         => 'publish',
                    'post_type'           => 'product',
                    'ignore_sticky_posts' => 1,
                    'posts_per_page'      => $params['number'],
                    'meta_key'            => 'total_sales',
                    'orderby'             => 'meta_value_num',
                    'order'               => 'DESC',
                );
                break;
            case 'featured':
                $tax_query = WC()->query->get_tax_query();
                $tax_query[] = array(
                    'taxonomy' => 'product_visibility',
                    'field'    => 'name',
                    'terms'    => 'featured',
                    'operator' => 'IN',
                );

                $args = array(
                    'post_status'    => 'publish',
                    'post_type'      => 'product',
                    'posts_per_page' => $params['number'],
                    'orderby'        => $params['orderby'],
                    'order'          => $params['sort_order'],
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'product_visibility',
                            'field'    => 'name',
                            'terms'    => 'featured',
                        ),
                    ),
                );
                break;
        }

        return $args;
    }

    private function getTitleStyles($params) {
        $styles = array();

        if (!empty($params['title_transform'])) {
            $styles[] = 'text-transform: ' . $params['title_transform'];
        }

        return implode(';', $styles);
    }
}