<?php

if ( ! function_exists( 'cyberstore_mikado_add_product_value_deal_slider_shortcode' ) ) {
	function cyberstore_mikado_add_product_value_deal_slider_shortcode( $shortcodes_class_name ) {
		$shortcodes = array(
			'MikadoCore\CPT\Shortcodes\ProductValueDealSlider\ProductValueDealSlider',
		);
		
		$shortcodes_class_name = array_merge( $shortcodes_class_name, $shortcodes );
		
		return $shortcodes_class_name;
	}
	
	if ( cyberstore_mikado_core_plugin_installed() ) {
		add_filter( 'mkd_core_filter_add_vc_shortcode', 'cyberstore_mikado_add_product_value_deal_slider_shortcode' );
	}
}

if ( ! function_exists( 'cyberstore_mikado_add_product_value_deal_slider_into_shortcodes_list' ) ) {
	function cyberstore_mikado_add_product_value_deal_slider_into_shortcodes_list( $woocommerce_shortcodes ) {
		$woocommerce_shortcodes[] = 'mkd_product_value_deal_slider';
		
		return $woocommerce_shortcodes;
	}
	
	add_filter( 'cyberstore_mikado_woocommerce_shortcodes_list', 'cyberstore_mikado_add_product_value_deal_slider_into_shortcodes_list' );
}