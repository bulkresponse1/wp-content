<?php

$params['title_styles'] = $this_object->getTitleStyles($params);
?>

<div class="mkd-pvd mkd-pvd-left">
<div class="mkd-pli-inner">
    <div class="mkd-pli-image">
        <?php cyberstore_mikado_get_module_template_part('templates/parts/image', 'woocommerce', '', $params); ?>
    </div>
    <a class="mkd-pli-link" itemprop="url" href="<?php the_permalink(); ?>"
       title="<?php the_title_attribute(); ?>"></a>
</div>
<div class="mkd-pvd-compare">
    <?php
    cyberstore_mikado_get_module_template_part('templates/parts/compare', 'woocommerce', '', $params);

    cyberstore_mikado_get_module_template_part('templates/parts/wishlist', 'woocommerce', '', $params);
    ?>
</div>
<div class="mkd-pli-content">
    <?php
    cyberstore_mikado_get_module_template_part('templates/parts/category', 'woocommerce', '', $params);

    ?>

    <?php

    cyberstore_mikado_get_module_template_part('templates/parts/title', 'woocommerce', '', $params);

    cyberstore_mikado_get_module_template_part('templates/parts/price', 'woocommerce', '', $params);

    ?>

    <?php
    cyberstore_mikado_get_module_template_part('templates/parts/value-deal', 'woocommerce', '', $params);

    ?>
</div>
<?php cyberstore_mikado_get_module_template_part('templates/parts/add-to-cart', 'woocommerce', '', $params); ?>
</div>
