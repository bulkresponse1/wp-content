<?php

namespace MikadoCore\CPT\Shortcodes\ProductValueDealSlider;

use MikadoCore\Lib;

class ProductValueDealSlider implements Lib\ShortcodeInterface
{
    private $base;

    function __construct() {
        $this->base = 'mkd_product_value_deal_slider';

        add_action('vc_before_init', array($this, 'vcMap'));
    }

    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        if (function_exists('vc_map')) {
            vc_map(
                array(
                    'name'                      => esc_html__('Mikado Product Value Deal - Slider', 'cyberstore'),
                    'base'                      => $this->base,
                    'icon'                      => 'icon-wpb-product-value-deal-slider extended-custom-icon',
                    'category'                  => esc_html__('by MIKADO', 'cyberstore'),
                    'allowed_container_element' => 'vc_row',
                    'params'                    => array(
                        array(
                            'type'       => 'textfield',
                            'param_name' => 'number_of_posts',
                            'heading'    => esc_html__('Number of Products', 'cyberstore')
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'orderby',
                            'heading'     => esc_html__('Order By', 'cyberstore'),
                            'value'       => array_flip(
                                array_merge(
                                    cyberstore_mikado_get_query_order_by_array(),
                                    array(
                                        'sales' => esc_html__('Sales', 'cyberstore'),
                                    )
                                )
                            ),
                            'save_always' => true
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'order',
                            'heading'     => esc_html__('Order', 'cyberstore'),
                            'value'       => array_flip(cyberstore_mikado_get_query_order_array()),
                            'save_always' => true
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'taxonomy_to_display',
                            'heading'     => esc_html__('Choose Sorting Taxonomy', 'cyberstore'),
                            'value'       => array(
                                esc_html__('Category', 'cyberstore') => 'category',
                                esc_html__('Tag', 'cyberstore')      => 'tag',
                                esc_html__('Id', 'cyberstore')       => 'id'
                            ),
                            'save_always' => true,
                            'description' => esc_html__('If you would like to display only certain products, this is where you can select the criteria by which you would like to choose which products to display', 'cyberstore')
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'taxonomy_values',
                            'heading'     => esc_html__('Enter Taxonomy Values', 'cyberstore'),
                            'description' => esc_html__('Separate values (category slugs, tags, or post IDs) with a comma', 'cyberstore')
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => esc_html__('Image Proportions', 'cyberstore'),
                            'param_name'  => 'image_size',
                            'value'       => array(
                                esc_html__('Default', 'cyberstore')        => '',
                                esc_html__('Original', 'cyberstore')       => 'full',
                                esc_html__('Square', 'cyberstore')         => 'square',
                                esc_html__('Landscape', 'cyberstore')      => 'landscape',
                                esc_html__('Portrait', 'cyberstore')       => 'portrait',
                                esc_html__('Medium', 'cyberstore')         => 'medium',
                                esc_html__('Large', 'cyberstore')          => 'large',
                                esc_html__('Shop Catalog', 'cyberstore')   => 'shop_catalog',
                                esc_html__('Shop Single', 'cyberstore')    => 'shop_single',
                                esc_html__('Shop Thumbnail', 'cyberstore') => 'shop_thumbnail'
                            ),
                            'save_always' => true
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'slider_autoplay',
                            'heading'     => esc_html__('Enable Slider Autoplay', 'cyberstore'),
                            'value'       => array_flip(cyberstore_mikado_get_yes_no_select_array(false, true)),
                            'save_always' => true,
                            'group'       => esc_html__('Slider Settings', 'cyberstore')
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'slider_speed',
                            'heading'     => esc_html__('Slide Duration', 'cyberstore'),
                            'description' => esc_html__('Default value is 5000 (ms)', 'cyberstore'),
                            'group'       => esc_html__('Slider Settings', 'cyberstore')
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'slider_speed_animation',
                            'heading'     => esc_html__('Slide Animation Duration', 'cyberstore'),
                            'description' => esc_html__('Speed of slide animation in milliseconds. Default value is 600.', 'cyberstore'),
                            'group'       => esc_html__('Slider Settings', 'cyberstore')
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'slider_navigation',
                            'heading'     => esc_html__('Enable Slider Navigation Arrows', 'cyberstore'),
                            'value'       => array_flip(cyberstore_mikado_get_yes_no_select_array(false, true)),
                            'save_always' => true,
                            'group'       => esc_html__('Slider Settings', 'cyberstore')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'display_title',
                            'heading'    => esc_html__('Display Title', 'cyberstore'),
                            'value'      => array_flip(cyberstore_mikado_get_yes_no_select_array(false, true)),
                            'group'      => esc_html__('Product Info', 'cyberstore')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'title_tag',
                            'heading'    => esc_html__('Title Tag', 'cyberstore'),
                            'value'      => array_flip(cyberstore_mikado_get_title_tag(true)),
                            'dependency' => array('element' => 'display_title', 'value' => array('yes')),
                            'group'      => esc_html__('Product Info Style', 'cyberstore')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'title_transform',
                            'heading'    => esc_html__('Title Text Transform', 'cyberstore'),
                            'value'      => array_flip(cyberstore_mikado_get_text_transform_array(true)),
                            'dependency' => array('element' => 'display_title', 'value' => array('yes')),
                            'group'      => esc_html__('Product Info Style', 'cyberstore')
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'display_compare',
                            'heading'     => esc_html__('Display Compare Button', 'cyberstore'),
                            'value'       => array_flip(cyberstore_mikado_get_yes_no_select_array(false)),
                            'description' => esc_html__('Wishlist button may appear only if YITH Compare plugin is installed', 'cyberstore'),
                            'group'       => esc_html__('Product Info', 'cyberstore')
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'display_wishlist',
                            'heading'     => esc_html__('Display Wishlist Button', 'cyberstore'),
                            'value'       => array_flip(cyberstore_mikado_get_yes_no_select_array(false)),
                            'description' => esc_html__('Wishlist button may appear only if YITH Wishlist plugin is installed', 'cyberstore'),
                            'group'       => esc_html__('Product Info', 'cyberstore')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'display_category',
                            'heading'    => esc_html__('Display Category', 'cyberstore'),
                            'value'      => array_flip(cyberstore_mikado_get_yes_no_select_array(false)),
                            'group'      => esc_html__('Product Info', 'cyberstore')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'display_rating',
                            'heading'    => esc_html__('Display Rating', 'cyberstore'),
                            'value'      => array_flip(cyberstore_mikado_get_yes_no_select_array(false, true)),
                            'group'      => esc_html__('Product Info', 'cyberstore')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'display_price',
                            'heading'    => esc_html__('Display Price', 'cyberstore'),
                            'value'      => array_flip(cyberstore_mikado_get_yes_no_select_array(false, true)),
                            'group'      => esc_html__('Product Info', 'cyberstore')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'display_button',
                            'heading'    => esc_html__('Display Button', 'cyberstore'),
                            'value'      => array_flip(cyberstore_mikado_get_yes_no_select_array(false, true)),
                            'group'      => esc_html__('Product Info', 'cyberstore')
                        ),
                    )
                )
            );
        }
    }

    public function render($atts, $content = null) {
        $default_atts = array(
            'number_of_posts'         => '8',
            'orderby'                => 'date',
            'order'                   => 'ASC',
            'taxonomy_to_display'     => 'category',
            'taxonomy_values'         => '',
            'image_size'              => 'full',
            'number_of_visible_items' => '1',
            'slider_loop'             => 'yes',
            'slider_autoplay'         => 'yes',
            'slider_speed'            => '5000',
            'slider_speed_animation'  => '600',
            'slider_navigation'       => 'yes',
            'slider_navigation_skin'  => 'default',
            'slider_navigation_pos'   => 'default',
            'display_title'           => 'yes',
            'title_tag'               => 'h3',
            'title_transform'         => '',
            'display_compare'         => 'no',
            'display_wishlist'        => 'no',
            'display_category'        => 'no',
            'display_rating'          => 'yes',
            'display_price'           => 'yes',
            'display_button'          => 'yes',
            'button_skin'             => 'default',
        );
        $params = shortcode_atts($default_atts, $atts);

        $params['class_name'] = 'pvd';
        $params['title_tag'] = !empty($params['title_tag']) ? $params['title_tag'] : $default_atts['title_tag'];

        $additional_params = array();
        $additional_params['holder_classes'] = $this->getHolderClasses($params, $default_atts);
        $additional_params['holder_data'] = $this->getProductListSliderDataAttributes($params);

        $queryArray = $this->generateProductQueryArray($params);
        $query_result = new \WP_Query($queryArray);
        $additional_params['query_result'] = $query_result;

        $params['this_object'] = $this;

        $html = cyberstore_mikado_get_woo_shortcode_module_template_part('templates/product-list', 'product-value-deal-slider', '', $params, $additional_params);

        return $html;
    }

    private function getHolderClasses($params, $default_atts) {
        $holderClasses = array();
        $holderClasses[] = $this->getsliderClasses($params, $default_atts);

        return implode(' ', $holderClasses);
    }

    private function getSliderClasses($params) {
        $sliderClasses = array();
        $sliderClasses[] = !empty($params['slider_navigation_pos']) ? 'mkd-plsl-nav-' . $params['slider_navigation_pos'] . '-pos' : '';
        $sliderClasses[] = !empty($params['slider_navigation_skin']) ? 'mkd-plsl-nav-' . $params['slider_navigation_skin'] . '-skin' : '';

        return implode(' ', $sliderClasses);
    }

    private function getProductListSliderDataAttributes($params) {
        $slider_data = array();

        $slider_data['data-number-of-items'] = !empty($params['number_of_visible_items']) ? $params['number_of_visible_items'] : '1';
        $slider_data['data-enable-loop'] = !empty($params['slider_loop']) ? $params['slider_loop'] : '';
        $slider_data['data-enable-autoplay'] = !empty($params['slider_autoplay']) ? $params['slider_autoplay'] : '';
        $slider_data['data-slider-speed'] = !empty($params['slider_speed']) ? $params['slider_speed'] : '5000';
        $slider_data['data-slider-speed-animation'] = !empty($params['slider_speed_animation']) ? $params['slider_speed_animation'] : '600';
        $slider_data['data-enable-navigation'] = !empty($params['slider_navigation']) ? $params['slider_navigation'] : '';
        $slider_data['data-enable-pagination'] = !empty($params['slider_pagination']) ? $params['slider_pagination'] : '';

        return $slider_data;
    }

    public function generateProductQueryArray($params) {
        $today = date("Y-m-d");
        $date = strtotime($today);
        $queryArray = array(
            'post_status'         => 'publish',
            'post_type'           => 'product',
            'ignore_sticky_posts' => 1,
            'posts_per_page'      => $params['number_of_posts'],
            'order'               => $params['order'],
            'meta_query'     => array(
                'relation' => 'AND',
                array(
                    'key'           => '_sale_price',
                    'value'         => 0,
                    'compare'       => '>',
                    'type'          => 'numeric'
                ),
                array(
                    'key'           => '_sale_price_dates_to',
                    'value'         => $date,
                    'compare'       => '>',
                )
            )
        );

        if ($params['orderby'] !== 'sales') {
            $queryArray['orderby'] = $params['orderby'];
        } else {
            $queryArray['meta_key'] = 'total_sales';
            $queryArray['orderby'] = 'meta_value_num';
        }

        if ($params['taxonomy_to_display'] !== '' && $params['taxonomy_to_display'] === 'category') {
            $queryArray['product_cat'] = $params['taxonomy_values'];
        }

        if ($params['taxonomy_to_display'] !== '' && $params['taxonomy_to_display'] === 'tag') {
            $queryArray['product_tag'] = $params['taxonomy_values'];
        }

        if ($params['taxonomy_to_display'] !== '' && $params['taxonomy_to_display'] === 'id') {
            $idArray = $params['taxonomy_values'];
            $ids = explode(',', $idArray);
            $queryArray['post__in'] = $ids;
        }

        return $queryArray;
    }

    public function getTitleStyles($params) {
        $styles = array();

        if (!empty($params['title_transform'])) {
            $styles[] = 'text-transform: ' . $params['title_transform'];
        }

        return implode(';', $styles);
    }
}