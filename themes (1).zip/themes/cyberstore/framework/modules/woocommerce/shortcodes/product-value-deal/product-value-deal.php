<?php
namespace MikadoCore\CPT\Shortcodes\ProductValueDeal;

use MikadoCore\Lib;

class ProductValueDeal implements Lib\ShortcodeInterface
{
    private $base;

    function __construct() {
        $this->base = 'mkd_product_value_deal';

        add_action('vc_before_init', array($this, 'vcMap'));

        //Product id filter
        add_filter('vc_autocomplete_mkd_product_value_deal_product_id_callback', array(&$this, 'productIdAutocompleteSuggester',), 10, 1);

        //Product id render
        add_filter('vc_autocomplete_mkd_product_value_deal_product_id_render', array(&$this, 'productIdAutocompleteRender',), 10, 1);
    }

    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        if (function_exists('vc_map')) {
            vc_map(
                array(
                    'name'                      => esc_html__('Mikado Product Value Deal', 'cyberstore'),
                    'base'                      => $this->getBase(),
                    'category'                  => esc_html__('by MIKADO', 'cyberstore'),
                    'icon'                      => 'icon-wpb-product-value-deal extended-custom-icon',
                    'allowed_container_element' => 'vc_row',
                    'params'                    => array(
                        array(
                            'type'        => 'autocomplete',
                            'param_name'  => 'product_id',
                            'heading'     => esc_html__('Selected Product', 'cyberstore'),
                            'settings'    => array(
                                'sortable'      => true,
                                'unique_values' => true
                            ),
                            'admin_label' => true,
                            'save_always' => true,
                            'description' => esc_html__('If you left this field empty then product ID will be of the current page', 'cyberstore')
                        ),

                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'product_vd_border',
                            'heading'     => esc_html__('Border', 'cyberstore'),
                            'value'       => array(
                                esc_html__('No', 'cyberstore')  => 'no',
                                esc_html__('Yes', 'cyberstore') => 'yes',
                            ),
                            'admin_label' => true
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'product_vd_image_position',
                            'heading'     => esc_html__('Image Position', 'cyberstore'),
                            'value'       => array(
                                esc_html__('Left', 'cyberstore')   => 'left',
                                esc_html__('Middle', 'cyberstore') => 'middle',
                            ),
                            'admin_label' => true
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'image_size',
                            'heading'     => esc_html__('Image Proportions', 'cyberstore'),
                            'value'       => array(
                                esc_html__('Default', 'cyberstore')        => '',
                                esc_html__('Original', 'cyberstore')       => 'full',
                                esc_html__('Square', 'cyberstore')         => 'square',
                                esc_html__('Landscape', 'cyberstore')      => 'landscape',
                                esc_html__('Portrait', 'cyberstore')       => 'portrait',
                                esc_html__('Medium', 'cyberstore')         => 'medium',
                                esc_html__('Large', 'cyberstore')          => 'large',
                                esc_html__('Shop Catalog', 'cyberstore')   => 'shop_catalog',
                                esc_html__('Shop Single', 'cyberstore')    => 'shop_single',
                                esc_html__('Shop Thumbnail', 'cyberstore') => 'shop_thumbnail'
                            ),
                            'save_always' => true
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'display_category',
                            'heading'    => esc_html__('Display Category', 'cyberstore'),
                            'value'      => array_flip(cyberstore_mikado_get_yes_no_select_array(false, true)),
                            'group'      => esc_html__('Product Info', 'cyberstore')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'display_title',
                            'heading'    => esc_html__('Display Title', 'cyberstore'),
                            'value'      => array_flip(cyberstore_mikado_get_yes_no_select_array(false, true)),
                            'group'      => esc_html__('Product Info', 'cyberstore')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'title_tag',
                            'heading'    => esc_html__('Title Tag', 'cyberstore'),
                            'value'      => array_flip(cyberstore_mikado_get_title_tag(true)),
                            'dependency' => array('element' => 'display_title', 'value' => array('yes')),
                            'group'      => esc_html__('Product Info', 'cyberstore')
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'display_compare',
                            'heading'     => esc_html__('Display Compare Button', 'cyberstore'),
                            'value'       => array_flip(cyberstore_mikado_get_yes_no_select_array(false)),
                            'description' => esc_html__('Wishlist button may appear only if YITH Compare plugin is installed', 'cyberstore'),
                            'group'       => esc_html__('Product Info', 'cyberstore')
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'display_wishlist',
                            'heading'     => esc_html__('Display Wishlist Button', 'cyberstore'),
                            'value'       => array_flip(cyberstore_mikado_get_yes_no_select_array(false)),
                            'description' => esc_html__('Wishlist button may appear only if YITH Wishlist plugin is installed', 'cyberstore'),
                            'group'       => esc_html__('Product Info', 'cyberstore')
                        ),
                    )
                )
            );
        }
    }

    public function render($atts, $content = null) {
        $args = array(
            'product_id'                => '',
            'product_vd_image_position' => 'left',
            'image_size'                => '',
            'product_vd_border'         => 'no',
            'display_category'          => 'yes',
            'display_title'             => 'yes',
            'title_tag'                 => 'h4',
            'display_compare'           => 'no',
            'display_wishlist'          => 'no',
        );

        $params = shortcode_atts($args, $atts);
        extract($params);

        $params['product_id'] = !empty($params['product_id']) ? $params['product_id'] : get_the_ID();

        $params['class_name'] = 'pvd';
        $params['title_styles'] = array();
        $params['display_price'] = 'yes';
        $params['display_button'] = 'yes';

        $params['product_vd_border'] = $this->getHolderClasses( $params, $args );
        $params['product_vd_style'] = $this->getProductVDClasses($params);

        $queryArray = $this->generateProductQueryArray($params);
        $query_result = new \WP_Query($queryArray);
        $params['query_result'] = $query_result;

        $html = cyberstore_mikado_get_woo_shortcode_module_template_part('templates/product-vd', 'product-value-deal', $params['product_vd_image_position'], $params);

        return $html;
    }

    private function getHolderClasses( $params, $args ) {
        $holderClasses = array();

        if($params['product_vd_border'] == 'yes') {
            $holderClasses[] = 'mkd-vd-border';
        }

        return implode( ' ', $holderClasses );
    }

    /**
     * Return product info styles
     *
     * @param $params
     *
     * @return array
     */
    private function getProductVDClasses($params) {
        $classes = array();

        return $classes;
    }

    /**
     * Filter product by ID or Title
     *
     * @param $query
     *
     * @return array
     */
    public function productIdAutocompleteSuggester($query) {
        global $wpdb;
        $product_id = (int)$query;
        $post_meta_infos = $wpdb->get_results($wpdb->prepare("SELECT ID AS id, post_title AS title
					FROM {$wpdb->posts} posts_table LEFT JOIN {$wpdb->postmeta} post_meta_table ON posts_table.ID = post_meta_table.post_id
					WHERE (posts_table.post_type = 'product' AND  post_meta_table.meta_key = '_sale_price' AND post_meta_table.meta_value <> '') AND ( ID = '%d' OR posts_table.post_title LIKE '%%%s%%' )", $product_id > 0 ? $product_id : -1, stripslashes($query), stripslashes($query)), ARRAY_A);

        $results = array();
        if (is_array($post_meta_infos) && !empty($post_meta_infos)) {
            foreach ($post_meta_infos as $value) {
                $data = array();
                $data['value'] = $value['id'];
                $data['label'] = esc_html__('Id', 'cyberstore') . ': ' . $value['id'] . ((strlen($value['title']) > 0) ? ' - ' . esc_html__('Title', 'cyberstore') . ': ' . $value['title'] : '');
                $results[] = $data;
            }
        }

        return $results;

    }

    /**
     * Find product by id
     * @since 4.4
     *
     * @param $query
     *
     * @return bool|array
     */
    public function productIdAutocompleteRender($query) {
        $query = trim($query['value']); // get value from requested
        if (!empty($query)) {

            $product = get_post((int)$query);
            if (!is_wp_error($product)) {

                $product_id = $product->ID;
                $product_title = $product->post_title;

                $product_title_display = '';
                if (!empty($product_title)) {
                    $product_title_display = ' - ' . esc_html__('Title', 'cyberstore') . ': ' . $product_title;
                }

                $product_id_display = esc_html__('Id', 'cyberstore') . ': ' . $product_id;

                $data = array();
                $data['value'] = $product_id;
                $data['label'] = $product_id_display . $product_title_display;

                return !empty($data) ? $data : false;
            }

            return false;
        }

        return false;
    }

    private function generateProductQueryArray($params) {
        $args = array(
            'post_status' => 'publish',
            'post_type'   => 'product',
            'post__in'    => array($params['product_id'])
        );

        return $args;
    }
}