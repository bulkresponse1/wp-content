<h5><?php esc_html_e('Hurry up! Offer ends in:', 'cyberstore'); ?></h5>

