<?php if ($show_category_filter == 'yes') { ?>
    <div class="mkd-pl-categories">
        <h4 class="mkd-pl-categories-label"><?php esc_html_e('Categories', 'cyberstore'); ?></h4>
        <ul>
            <?php echo cyberstore_mikado_get_module_part($categories_filter_list); ?>
        </ul>
    </div>
<?php } ?>