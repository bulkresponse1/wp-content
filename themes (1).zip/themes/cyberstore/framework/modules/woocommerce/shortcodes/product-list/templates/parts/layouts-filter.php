<?php if ($show_layouts_filter == 'yes') { ?>

    <div class="mkd-pl-layouts">
        <h4 class="mkd-pl-layouts-label"><?php esc_html_e('Layouts', 'cyberstore'); ?></h4>
        <ul>
            <?php echo cyberstore_mikado_get_module_part($layout_list); ?>
        </ul>
    </div>

<?php } ?>