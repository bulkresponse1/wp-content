<?php

$product = cyberstore_mikado_return_woocommerce_global_variable();

$product_sku = $product->get_sku();

if (!empty($product_sku)) {
    ?>
    <span
        class="mkd-pli-sku"><?php esc_html_e('SKU: ', 'cyberstore'); ?><?php echo esc_html($product->get_sku()) ?></span>
<?php } ?>