<?php

if (cyberstore_mikado_is_yith_compare_installed() && $display_compare == 'yes') {

    $button_text = get_option('yith_woocompare_button_text', __('Compare', 'cyberstore'));

    $url_action = 'action=yith-woocompare-add-product';

    $id = get_the_ID();

    $url_id = 'id=' . $id;

    $url = home_url() . '?' . $url_action . '&' . $url_id;

    ?>
    <div class="woocommerce product compare-button">
        <a class="compare" rel="nofollow" data-product_id="<?php echo esc_attr($id); ?>" href="<?php echo esc_url($url); ?>" title="<?php echo esc_attr__('Add to Product Compare List', 'cyberstore'); ?>">
            <?php print esc_attr($button_text); ?>
        </a>
    </div>
<?php
}