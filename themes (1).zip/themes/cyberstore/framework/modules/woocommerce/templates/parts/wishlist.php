<?php

if ($display_wishlist == 'yes') {
    cyberstore_mikado_woocommerce_wishlist_shortcode();
}