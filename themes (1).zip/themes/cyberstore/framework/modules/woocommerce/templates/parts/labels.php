<?php

$product = cyberstore_mikado_return_woocommerce_global_variable();

$product_id = $product->get_id();

?>

<div class="mkd-labels-holder">
    <?php if (get_post_meta($product_id, 'mkd_single_product_new_meta', true) === 'yes') { ?>
        <span
            class="mkd-<?php echo esc_attr($class_name); ?>-new-product"><?php esc_html_e('New', 'cyberstore'); ?></span>
    <?php } ?>
</div>
