<?php

$product = cyberstore_mikado_return_woocommerce_global_variable();

if ( $product->is_in_stock() && $product->get_manage_stock() ) { ?>
    <div class="mkd-pli-stock-availability"><?php esc_html_e('Availability: ', 'cyberstore'); ?><?php echo wc_get_stock_html($product);?></div>
<?php } ?>