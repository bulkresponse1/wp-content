<?php

if (!function_exists('cyberstore_mikado_map_woocommerce_meta')) {
    function cyberstore_mikado_map_woocommerce_meta() {
        $woocommerce_meta_box = cyberstore_mikado_create_meta_box(
            array(
                'scope' => array('product'),
                'title' => esc_html__('Product Meta', 'cyberstore'),
                'name'  => 'woo_product_meta'
            )
        );

        cyberstore_mikado_create_meta_box_field(array(
            'name'        => 'mkd_product_featured_image_size',
            'type'        => 'select',
            'label'       => esc_html__('Dimensions for Product List Shortcode', 'cyberstore'),
            'description' => esc_html__('Choose product layout when it appears in Mikado Product List - Masonry layout shortcode', 'cyberstore'),
            'parent'      => $woocommerce_meta_box,
            'options'     => array(
                'mkd-woo-image-normal-width' => esc_html__('Default', 'cyberstore'),
                'mkd-woo-image-large-width'  => esc_html__('Large Width', 'cyberstore')
            )
        ));

        cyberstore_mikado_create_meta_box_field(array(
            'name'          => 'mkd_product_advanced_list_size',
            'type'          => 'select',
            'default_value' => 'left',
            'label'         => esc_html__('Image position for Advanced Product List Shortcode', 'cyberstore'),
            'description'   => esc_html__('Choose product layout when it appears in Mikado Product List Advanced - Blocks layout shortcode', 'cyberstore'),
            'parent'        => $woocommerce_meta_box,
            'options'       => array(
                'left'   => esc_html__('Left', 'cyberstore'),
                'middle' => esc_html__('Middle', 'cyberstore')
            )
        ));

        cyberstore_mikado_create_meta_box_field(
            array(
                'name'          => 'mkd_show_title_area_woo_meta',
                'type'          => 'select',
                'default_value' => '',
                'label'         => esc_html__('Show Title Area', 'cyberstore'),
                'description'   => esc_html__('Disabling this option will turn off page title area', 'cyberstore'),
                'parent'        => $woocommerce_meta_box,
                'options'       => cyberstore_mikado_get_yes_no_select_array()
            )
        );

        cyberstore_mikado_create_meta_box_field(array(
            'name'        => 'mkd_single_product_new_meta',
            'type'        => 'select',
            'label'       => esc_html__('Enable New Product Mark', 'cyberstore'),
            'description' => esc_html__('Enabling this option will show new product mark on your product lists and product single', 'cyberstore'),
            'parent'      => $woocommerce_meta_box,
            'options'     => array(
                'no'  => esc_html__('No', 'cyberstore'),
                'yes' => esc_html__('Yes', 'cyberstore')
            )
        ));
    }

    add_action('cyberstore_mikado_meta_boxes_map', 'cyberstore_mikado_map_woocommerce_meta', 99);
}