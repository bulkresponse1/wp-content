<?php

if ( ! function_exists( 'cyberstore_mikado_woocommerce_options_map' ) ) {
	
	/**
	 * Add Woocommerce options page
	 */
	function cyberstore_mikado_woocommerce_options_map() {
		
		cyberstore_mikado_add_admin_page(
			array(
				'slug'  => '_woocommerce_page',
				'title' => esc_html__( 'Woocommerce', 'cyberstore' ),
				'icon'  => 'icon_cart_alt'
			)
		);
		
		/**
		 * Product List Settings
		 */
		$panel_product_list = cyberstore_mikado_add_admin_panel(
			array(
				'page'  => '_woocommerce_page',
				'name'  => 'panel_product_list',
				'title' => esc_html__( 'Product List', 'cyberstore' )
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'name'          => 'mkd_woo_product_list_columns',
				'type'          => 'select',
				'label'         => esc_html__( 'Product List Columns', 'cyberstore' ),
				'default_value' => 'mkd-woocommerce-columns-4',
				'description'   => esc_html__( 'Choose number of columns for product listing and related products on single product', 'cyberstore' ),
				'options'       => array(
					'mkd-woocommerce-columns-3' => esc_html__( '3 Columns', 'cyberstore' ),
					'mkd-woocommerce-columns-4' => esc_html__( '4 Columns', 'cyberstore' )
				),
				'parent'        => $panel_product_list,
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'name'          => 'mkd_woo_product_list_columns_space',
				'type'          => 'select',
				'label'         => esc_html__( 'Space Between Items', 'cyberstore' ),
				'description'   => esc_html__( 'Select space between items for product listing and related products on single product', 'cyberstore' ),
				'default_value' => 'normal',
				'options'       => cyberstore_mikado_get_space_between_items_array(),
				'parent'        => $panel_product_list,
			)
		);
        
		cyberstore_mikado_add_admin_field(
			array(
				'name'          => 'mkd_woo_products_per_page',
				'type'          => 'text',
				'label'         => esc_html__( 'Number of products per page', 'cyberstore' ),
				'description'   => esc_html__( 'Set number of products on shop page', 'cyberstore' ),
				'parent'        => $panel_product_list,
				'args'          => array(
					'col_width' => 3
				)
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'name'          => 'mkd_products_list_title_tag',
				'type'          => 'select',
				'label'         => esc_html__( 'Products Title Tag', 'cyberstore' ),
				'default_value' => 'h5',
				'options'       => cyberstore_mikado_get_title_tag(),
				'parent'        => $panel_product_list,
			)
		);

        cyberstore_mikado_add_admin_field(
            array(
                'name'          => 'mkd_products_title_min_height',
                'type'          => 'text',
                'label'         => esc_html__('Product Title Minimal Height', 'cyberstore'),
                'default_value' => '',
                'parent'        => $panel_product_list,
            )
        );

        if (cyberstore_mikado_is_yith_compare_installed()) {
            cyberstore_mikado_add_admin_field(
                array(
                    'type'          => 'select',
                    'name'          => 'mkd_products_list_disable_compare_popup_styles',
                    'default_value' => 'yes',
                    'label'         => esc_html__('Enable Theme Styles for YITH Compare Pop Up', 'cyberstore'),
                    'description'   => esc_html__('Enabling this option will add the styles to YITH Compare Pop Up included by our Theme', 'cyberstore'),
                    'parent'        => $panel_product_list,
                    'options'       => cyberstore_mikado_get_yes_no_select_array(false, true),
                    'args'          => array(
                        'col_width' => 3
                    )
                )
            );
        }
		
		/**
		 * Single Product Settings
		 */
		$panel_single_product = cyberstore_mikado_add_admin_panel(
			array(
				'page'  => '_woocommerce_page',
				'name'  => 'panel_single_product',
				'title' => esc_html__( 'Single Product', 'cyberstore' )
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'type'          => 'select',
				'name'          => 'show_title_area_woo',
				'default_value' => '',
				'label'         => esc_html__( 'Show Title Area', 'cyberstore' ),
				'description'   => esc_html__( 'Enabling this option will show title area on single post pages', 'cyberstore' ),
				'parent'        => $panel_single_product,
				'options'       => cyberstore_mikado_get_yes_no_select_array(),
				'args'          => array(
					'col_width' => 3
				)
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'name'          => 'mkd_single_product_title_tag',
				'type'          => 'select',
				'default_value' => 'h2',
				'label'         => esc_html__( 'Single Product Title Tag', 'cyberstore' ),
				'options'       => cyberstore_mikado_get_title_tag(),
				'parent'        => $panel_single_product,
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'name'          => 'woo_set_thumb_images_position',
				'type'          => 'select',
				'default_value' => 'below-image',
				'label'         => esc_html__( 'Set Thumbnail Images Position', 'cyberstore' ),
				'options'       => array(
					'below-image'  => esc_html__( 'Below Featured Image', 'cyberstore' ),
					'on-left-side' => esc_html__( 'On The Left Side Of Featured Image', 'cyberstore' )
				),
				'parent'        => $panel_single_product
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'type'          => 'select',
				'name'          => 'woo_enable_single_product_zoom_image',
				'default_value' => 'no',
				'label'         => esc_html__( 'Enable Zoom Maginfier', 'cyberstore' ),
				'description'   => esc_html__( 'Enabling this option will show magnifier image on featured image hover', 'cyberstore' ),
				'parent'        => $panel_single_product,
				'options'       => cyberstore_mikado_get_yes_no_select_array( false ),
				'args'          => array(
					'col_width' => 3
				)
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'name'          => 'woo_set_single_images_behavior',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Set Images Behavior', 'cyberstore' ),
				'options'       => array(
					''             => esc_html__( 'No Behavior', 'cyberstore' ),
					'pretty-photo' => esc_html__( 'Pretty Photo Lightbox', 'cyberstore' ),
					'photo-swipe'  => esc_html__( 'Photo Swipe Lightbox', 'cyberstore' )
				),
				'parent'        => $panel_single_product
			)
		);
	}
	
	add_action( 'cyberstore_mikado_options_map', 'cyberstore_mikado_woocommerce_options_map', 21 );
}