<?php

if ( ! function_exists( 'cyberstore_mikado_get_hide_dep_for_header_logo_area_options' ) ) {
	function cyberstore_mikado_get_hide_dep_for_header_logo_area_options() {
		$hide_dep_options = apply_filters( 'cyberstore_mikado_header_logo_area_hide_global_option', $hide_dep_options = array() );
		
		return $hide_dep_options;
	}
}

if ( ! function_exists( 'cyberstore_mikado_header_logo_area_options_map' ) ) {
	function cyberstore_mikado_header_logo_area_options_map( $panel_header ) {
		$hide_dep_options = cyberstore_mikado_get_hide_dep_for_header_logo_area_options();
		
		$logo_area_container = cyberstore_mikado_add_admin_container_no_style(
			array(
				'parent'          => $panel_header,
				'name'            => 'logo_area_container',
				'hidden_property' => 'header_type',
				'hidden_values'   => $hide_dep_options
			)
		);
		
		cyberstore_mikado_add_admin_section_title(
			array(
				'parent' => $logo_area_container,
				'name'   => 'logo_menu_area_title',
				'title'  => esc_html__( 'Logo Area', 'cyberstore' )
			)
		);

        cyberstore_mikado_add_admin_field(
            array(
                'parent'        => $logo_area_container,
                'type'          => 'select',
                'name'          => 'logo_area_skin',
                'default_value' => '',
                'label'         => esc_html__( 'Logo Area Skin', 'cyberstore' ),
                'description'   => esc_html__( 'Choose a predefined Skin for Logo Area header elements.', 'cyberstore' ),
                'options'       => array(
                    ''             => esc_html__( 'Default', 'cyberstore' ),
                    'logo-area-light-header' => esc_html__( 'Light', 'cyberstore' ),
                    'logo-area-dark-header'  => esc_html__( 'Dark', 'cyberstore' )
                ),
            )
        );
		
		cyberstore_mikado_add_admin_field(
			array(
				'parent'        => $logo_area_container,
				'type'          => 'yesno',
				'name'          => 'logo_area_in_grid',
				'default_value' => 'no',
				'label'         => esc_html__( 'Logo Area In Grid', 'cyberstore' ),
				'description'   => esc_html__( 'Set menu area content to be in grid', 'cyberstore' ),
				'args'          => array(
					'dependence'             => true,
					'dependence_hide_on_yes' => '',
					'dependence_show_on_yes' => '#mkd_logo_area_in_grid_container'
				)
			)
		);
		
		$logo_area_in_grid_container = cyberstore_mikado_add_admin_container(
			array(
				'parent'          => $logo_area_container,
				'name'            => 'logo_area_in_grid_container',
				'hidden_property' => 'logo_area_in_grid',
				'hidden_value'    => 'no'
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'parent'        => $logo_area_in_grid_container,
				'type'          => 'color',
				'name'          => 'logo_area_grid_background_color',
				'default_value' => '',
				'label'         => esc_html__( 'Grid Background Color', 'cyberstore' ),
				'description'   => esc_html__( 'Set grid background color for logo area', 'cyberstore' ),
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'parent'        => $logo_area_in_grid_container,
				'type'          => 'text',
				'name'          => 'logo_area_grid_background_transparency',
				'default_value' => '',
				'label'         => esc_html__( 'Grid Background Transparency', 'cyberstore' ),
				'description'   => esc_html__( 'Set grid background transparency', 'cyberstore' ),
				'args'          => array(
					'col_width' => 3
				)
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'parent'        => $logo_area_in_grid_container,
				'type'          => 'yesno',
				'name'          => 'logo_area_in_grid_border',
				'default_value' => 'no',
				'label'         => esc_html__( 'Grid Area Border', 'cyberstore' ),
				'description'   => esc_html__( 'Set border on grid area', 'cyberstore' ),
				'args'          => array(
					'dependence'             => true,
					'dependence_hide_on_yes' => '',
					'dependence_show_on_yes' => '#mkd_logo_area_in_grid_border_container'
				)
			)
		);
		
		$logo_area_in_grid_border_container = cyberstore_mikado_add_admin_container(
			array(
				'parent'          => $logo_area_in_grid_container,
				'name'            => 'logo_area_in_grid_border_container',
				'hidden_property' => 'logo_area_in_grid_border',
				'hidden_value'    => 'no'
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'parent'        => $logo_area_in_grid_border_container,
				'type'          => 'color',
				'name'          => 'logo_area_in_grid_border_color',
				'default_value' => '',
				'label'         => esc_html__( 'Border Color', 'cyberstore' ),
				'description'   => esc_html__( 'Set border color for grid area', 'cyberstore' ),
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'parent'        => $logo_area_container,
				'type'          => 'color',
				'name'          => 'logo_area_background_color',
				'default_value' => '',
				'label'         => esc_html__( 'Background Color', 'cyberstore' ),
				'description'   => esc_html__( 'Set background color for logo area', 'cyberstore' )
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'parent'        => $logo_area_container,
				'type'          => 'text',
				'name'          => 'logo_area_background_transparency',
				'default_value' => '',
				'label'         => esc_html__( 'Background Transparency', 'cyberstore' ),
				'description'   => esc_html__( 'Set background transparency for logo area', 'cyberstore' ),
				'args'          => array(
					'col_width' => 3
				)
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'parent'        => $logo_area_container,
				'type'          => 'yesno',
				'name'          => 'logo_area_border',
				'default_value' => 'no',
				'label'         => esc_html__( 'Logo Area Border', 'cyberstore' ),
				'description'   => esc_html__( 'Set border on logo area', 'cyberstore' ),
				'args'          => array(
					'dependence'             => true,
					'dependence_hide_on_yes' => '',
					'dependence_show_on_yes' => '#mkd_logo_area_border_container'
				)
			)
		);
		
		$logo_area_border_container = cyberstore_mikado_add_admin_container(
			array(
				'parent'          => $logo_area_container,
				'name'            => 'logo_area_border_container',
				'hidden_property' => 'logo_area_border',
				'hidden_value'    => 'no'
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'parent'        => $logo_area_border_container,
				'type'          => 'color',
				'name'          => 'logo_area_border_color',
				'default_value' => '',
				'label'         => esc_html__( 'Border Color', 'cyberstore' ),
				'description'   => esc_html__( 'Set border color for logo area', 'cyberstore' ),
			)
		);
		
		cyberstore_mikado_add_admin_field(
			array(
				'parent'        => $logo_area_container,
				'type'          => 'text',
				'name'          => 'logo_area_height',
				'default_value' => '',
				'label'         => esc_html__( 'Height', 'cyberstore' ),
				'description'   => esc_html__( 'Enter logo area height (default is 90px)', 'cyberstore' ),
				'args'          => array(
					'col_width' => 3,
					'suffix'    => 'px'
				)
			)
		);
		
		do_action( 'cyberstore_mikado_header_logo_area_additional_options', $logo_area_container );
	}
	
	add_action( 'cyberstore_mikado_header_logo_area_options_map', 'cyberstore_mikado_header_logo_area_options_map', 10, 1 );
}