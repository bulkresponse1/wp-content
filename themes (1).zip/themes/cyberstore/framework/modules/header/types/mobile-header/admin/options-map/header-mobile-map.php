<?php

if ( ! function_exists( 'cyberstore_mikado_mobile_header_options_map' ) ) {
	function cyberstore_mikado_mobile_header_options_map() {
		
		$panel_mobile_header = cyberstore_mikado_add_admin_panel(
			array(
				'title' => esc_html__( 'Mobile Header', 'cyberstore' ),
				'name'  => 'panel_mobile_header',
				'page'  => '_header_page'
			)
		);

		$mobile_header_group = cyberstore_mikado_add_admin_group(
			array(
				'parent' => $panel_mobile_header,
				'name'   => 'mobile_header_group',
				'title'  => esc_html__( 'Mobile Header Styles', 'cyberstore' )
			)
		);

		$mobile_header_row1 = cyberstore_mikado_add_admin_row(
			array(
				'parent' => $mobile_header_group,
				'name'   => 'mobile_header_row1'
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_header_height',
				'type'   => 'textsimple',
				'label'  => esc_html__( 'Height', 'cyberstore' ),
				'parent' => $mobile_header_row1,
				'args'   => array(
					'col_width' => 3,
					'suffix'    => 'px'
				)
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_header_background_color',
				'type'   => 'colorsimple',
				'label'  => esc_html__( 'Background Color', 'cyberstore' ),
				'parent' => $mobile_header_row1
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_header_border_bottom_color',
				'type'   => 'colorsimple',
				'label'  => esc_html__( 'Border Bottom Color', 'cyberstore' ),
				'parent' => $mobile_header_row1
			)
		);

		$mobile_menu_group = cyberstore_mikado_add_admin_group(
			array(
				'parent' => $panel_mobile_header,
				'name'   => 'mobile_menu_group',
				'title'  => esc_html__( 'Mobile Menu Styles', 'cyberstore' )
			)
		);

		$mobile_menu_row1 = cyberstore_mikado_add_admin_row(
			array(
				'parent' => $mobile_menu_group,
				'name'   => 'mobile_menu_row1'
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_menu_background_color',
				'type'   => 'colorsimple',
				'label'  => esc_html__( 'Background Color', 'cyberstore' ),
				'parent' => $mobile_menu_row1
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_menu_border_bottom_color',
				'type'   => 'colorsimple',
				'label'  => esc_html__( 'Border Bottom Color', 'cyberstore' ),
				'parent' => $mobile_menu_row1
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_menu_separator_color',
				'type'   => 'colorsimple',
				'label'  => esc_html__( 'Menu Item Separator Color', 'cyberstore' ),
				'parent' => $mobile_menu_row1
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'        => 'mobile_logo_height',
				'type'        => 'text',
				'label'       => esc_html__( 'Logo Height For Mobile Header', 'cyberstore' ),
				'description' => esc_html__( 'Define logo height for screen size smaller than 1024px', 'cyberstore' ),
				'parent'      => $panel_mobile_header,
				'args'        => array(
					'col_width' => 3,
					'suffix'    => 'px'
				)
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'        => 'mobile_logo_height_phones',
				'type'        => 'text',
				'label'       => esc_html__( 'Logo Height For Mobile Devices', 'cyberstore' ),
				'description' => esc_html__( 'Define logo height for screen size smaller than 480px', 'cyberstore' ),
				'parent'      => $panel_mobile_header,
				'args'        => array(
					'col_width' => 3,
					'suffix'    => 'px'
				)
			)
		);

		cyberstore_mikado_add_admin_section_title(
			array(
				'parent' => $panel_mobile_header,
				'name'   => 'mobile_header_fonts_title',
				'title'  => esc_html__( 'Typography', 'cyberstore' )
			)
		);

		$first_level_group = cyberstore_mikado_add_admin_group(
			array(
				'parent'      => $panel_mobile_header,
				'name'        => 'first_level_group',
				'title'       => esc_html__( '1st Level Menu', 'cyberstore' ),
				'description' => esc_html__( 'Define styles for 1st level in Mobile Menu Navigation', 'cyberstore' )
			)
		);

		$first_level_row1 = cyberstore_mikado_add_admin_row(
			array(
				'parent' => $first_level_group,
				'name'   => 'first_level_row1'
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_text_color',
				'type'   => 'colorsimple',
				'label'  => esc_html__( 'Text Color', 'cyberstore' ),
				'parent' => $first_level_row1
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_text_hover_color',
				'type'   => 'colorsimple',
				'label'  => esc_html__( 'Hover/Active Text Color', 'cyberstore' ),
				'parent' => $first_level_row1
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_text_google_fonts',
				'type'   => 'fontsimple',
				'label'  => esc_html__( 'Font Family', 'cyberstore' ),
				'parent' => $first_level_row1
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_text_font_size',
				'type'   => 'textsimple',
				'label'  => esc_html__( 'Font Size', 'cyberstore' ),
				'parent' => $first_level_row1,
				'args'   => array(
					'col_width' => 3,
					'suffix'    => 'px'
				)
			)
		);

		$first_level_row2 = cyberstore_mikado_add_admin_row(
			array(
				'parent' => $first_level_group,
				'name'   => 'first_level_row2'
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_text_line_height',
				'type'   => 'textsimple',
				'label'  => esc_html__( 'Line Height', 'cyberstore' ),
				'parent' => $first_level_row2,
				'args'   => array(
					'col_width' => 3,
					'suffix'    => 'px'
				)
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'    => 'mobile_text_text_transform',
				'type'    => 'selectsimple',
				'label'   => esc_html__( 'Text Transform', 'cyberstore' ),
				'parent'  => $first_level_row2,
				'options' => cyberstore_mikado_get_text_transform_array()
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'    => 'mobile_text_font_style',
				'type'    => 'selectsimple',
				'label'   => esc_html__( 'Font Style', 'cyberstore' ),
				'parent'  => $first_level_row2,
				'options' => cyberstore_mikado_get_font_style_array()
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'    => 'mobile_text_font_weight',
				'type'    => 'selectsimple',
				'label'   => esc_html__( 'Font Weight', 'cyberstore' ),
				'parent'  => $first_level_row2,
				'options' => cyberstore_mikado_get_font_weight_array()
			)
		);

		$first_level_row3 = cyberstore_mikado_add_admin_row(
			array(
				'parent' => $first_level_group,
				'name'   => 'first_level_row3'
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'type'          => 'textsimple',
				'name'          => 'mobile_text_letter_spacing',
				'label'         => esc_html__( 'Letter Spacing', 'cyberstore' ),
				'default_value' => '',
				'parent'        => $first_level_row3,
				'args'          => array(
					'suffix' => 'px'
				)
			)
		);

		$second_level_group = cyberstore_mikado_add_admin_group(
			array(
				'parent'      => $panel_mobile_header,
				'name'        => 'second_level_group',
				'title'       => esc_html__( 'Dropdown Menu', 'cyberstore' ),
				'description' => esc_html__( 'Define styles for drop down menu items in Mobile Menu Navigation', 'cyberstore' )
			)
		);

		$second_level_row1 = cyberstore_mikado_add_admin_row(
			array(
				'parent' => $second_level_group,
				'name'   => 'second_level_row1'
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_dropdown_text_color',
				'type'   => 'colorsimple',
				'label'  => esc_html__( 'Text Color', 'cyberstore' ),
				'parent' => $second_level_row1
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_dropdown_text_hover_color',
				'type'   => 'colorsimple',
				'label'  => esc_html__( 'Hover/Active Text Color', 'cyberstore' ),
				'parent' => $second_level_row1
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_dropdown_text_google_fonts',
				'type'   => 'fontsimple',
				'label'  => esc_html__( 'Font Family', 'cyberstore' ),
				'parent' => $second_level_row1
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_dropdown_text_font_size',
				'type'   => 'textsimple',
				'label'  => esc_html__( 'Font Size', 'cyberstore' ),
				'parent' => $second_level_row1,
				'args'   => array(
					'col_width' => 3,
					'suffix'    => 'px'
				)
			)
		);

		$second_level_row2 = cyberstore_mikado_add_admin_row(
			array(
				'parent' => $second_level_group,
				'name'   => 'second_level_row2'
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_dropdown_text_line_height',
				'type'   => 'textsimple',
				'label'  => esc_html__( 'Line Height', 'cyberstore' ),
				'parent' => $second_level_row2,
				'args'   => array(
					'col_width' => 3,
					'suffix'    => 'px'
				)
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'    => 'mobile_dropdown_text_text_transform',
				'type'    => 'selectsimple',
				'label'   => esc_html__( 'Text Transform', 'cyberstore' ),
				'parent'  => $second_level_row2,
				'options' => cyberstore_mikado_get_text_transform_array()
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'    => 'mobile_dropdown_text_font_style',
				'type'    => 'selectsimple',
				'label'   => esc_html__( 'Font Style', 'cyberstore' ),
				'parent'  => $second_level_row2,
				'options' => cyberstore_mikado_get_font_style_array()
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'    => 'mobile_dropdown_text_font_weight',
				'type'    => 'selectsimple',
				'label'   => esc_html__( 'Font Weight', 'cyberstore' ),
				'parent'  => $second_level_row2,
				'options' => cyberstore_mikado_get_font_weight_array()
			)
		);

		$second_level_row3 = cyberstore_mikado_add_admin_row(
			array(
				'parent' => $second_level_group,
				'name'   => 'second_level_row3'
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'type'          => 'textsimple',
				'name'          => 'mobile_dropdown_text_letter_spacing',
				'label'         => esc_html__( 'Letter Spacing', 'cyberstore' ),
				'default_value' => '',
				'parent'        => $second_level_row3,
				'args'          => array(
					'suffix' => 'px'
				)
			)
		);

		cyberstore_mikado_add_admin_section_title(
			array(
				'name'   => 'mobile_opener_panel',
				'parent' => $panel_mobile_header,
				'title'  => esc_html__( 'Mobile Menu Opener', 'cyberstore' )
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'        => 'mobile_menu_title',
				'type'        => 'text',
				'label'       => esc_html__( 'Mobile Navigation Title', 'cyberstore' ),
				'description' => esc_html__( 'Enter title for mobile menu navigation', 'cyberstore' ),
				'parent'      => $panel_mobile_header,
				'args'        => array(
					'col_width' => 3
				)
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_icon_color',
				'type'   => 'color',
				'label'  => esc_html__( 'Mobile Navigation Icon Color', 'cyberstore' ),
				'parent' => $panel_mobile_header
			)
		);

		cyberstore_mikado_add_admin_field(
			array(
				'name'   => 'mobile_icon_hover_color',
				'type'   => 'color',
				'label'  => esc_html__( 'Mobile Navigation Icon Hover Color', 'cyberstore' ),
				'parent' => $panel_mobile_header
			)
		);
	}
	
	add_action( 'cyberstore_mikado_mobile_header_options_map', 'cyberstore_mikado_mobile_header_options_map', 10, 1);
}