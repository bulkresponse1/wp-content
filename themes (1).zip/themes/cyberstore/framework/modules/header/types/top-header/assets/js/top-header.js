(function($) {
    "use strict";

    var topHeader = {};
    mkd.modules.topHeader = topHeader;

    topHeader.mkdOnDocumentReady = mkdOnDocumentReady;

    $(document).ready(mkdOnDocumentReady);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function mkdOnDocumentReady() {
        mkdHeaderTopCustomMenu();
    }

    /*
     **	Additional markup
     */
    function mkdHeaderTopCustomMenu() {
        var menuItems = $('.mkd-top-bar .widget_nav_menu .sub-menu li a');

        menuItems.each(function() {
            var menuItem = this;

            $(menuItem).wrap("<span class='mkd-item-outer'><span class='mkd-item-inner'></span></span>");

        });

    }

})(jQuery);