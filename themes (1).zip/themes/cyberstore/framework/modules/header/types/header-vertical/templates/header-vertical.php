<?php do_action('cyberstore_mikado_before_page_header'); ?>

<aside class="mkd-vertical-menu-area <?php echo esc_attr($holder_class); ?>">
	<div class="mkd-vertical-menu-area-inner">
		<div class="mkd-vertical-area-background"></div>
		<?php if(!$hide_logo) {
			cyberstore_mikado_get_logo();
		} ?>
		<?php cyberstore_mikado_get_header_vertical_main_menu(); ?>
		<div class="mkd-vertical-area-widget-holder">
			<?php cyberstore_mikado_get_header_vertical_widget_areas(); ?>
		</div>
	</div>
</aside>

<?php do_action('cyberstore_mikado_after_page_header'); ?>