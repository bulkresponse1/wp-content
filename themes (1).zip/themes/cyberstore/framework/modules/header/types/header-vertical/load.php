<?php

include_once MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-vertical/functions.php';
include_once MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-vertical/header-vertical.php';