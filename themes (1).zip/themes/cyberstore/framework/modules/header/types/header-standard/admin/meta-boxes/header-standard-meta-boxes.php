<?php

if ( ! function_exists( 'cyberstore_mikado_get_hide_dep_for_header_standard_meta_boxes' ) ) {
	function cyberstore_mikado_get_hide_dep_for_header_standard_meta_boxes() {
		$hide_dep_options = apply_filters( 'cyberstore_mikado_header_standard_hide_meta_boxes', $hide_dep_options = array() );
		
		return $hide_dep_options;
	}
}

if ( ! function_exists( 'cyberstore_mikado_header_standard_meta_map' ) ) {
	function cyberstore_mikado_header_standard_meta_map( $parent ) {
		$hide_dep_options = cyberstore_mikado_get_hide_dep_for_header_standard_meta_boxes();
		
		cyberstore_mikado_create_meta_box_field(
			array(
				'parent'          => $parent,
				'type'            => 'select',
				'name'            => 'mkd_set_menu_area_position_meta',
				'default_value'   => '',
				'label'           => esc_html__( 'Choose Menu Area Position', 'cyberstore' ),
				'description'     => esc_html__( 'Select menu area position in your header', 'cyberstore' ),
				'options'         => array(
					''       => esc_html__( 'Default', 'cyberstore' ),
					'left'   => esc_html__( 'Left', 'cyberstore' ),
					'right'  => esc_html__( 'Right', 'cyberstore' ),
					'center' => esc_html__( 'Center', 'cyberstore' )
				),
				'hidden_property' => 'mkd_header_type_meta',
				'hidden_values'   => $hide_dep_options
			)
		);
	}
	
	add_action( 'cyberstore_mikado_additional_header_area_meta_boxes_map', 'cyberstore_mikado_header_standard_meta_map' );
}