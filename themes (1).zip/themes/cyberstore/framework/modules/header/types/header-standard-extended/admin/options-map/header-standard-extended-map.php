<?php

if (!function_exists('cyberstore_mikado_get_hide_dep_for_header_standard_extended_options')) {
    function cyberstore_mikado_get_hide_dep_for_header_standard_extended_options() {
        $hide_dep_options = apply_filters('cyberstore_mikado_header_standard_extended_hide_global_option', $hide_dep_options = array());

        return $hide_dep_options;
    }
}

if (!function_exists('cyberstore_mikado_header_standard_extended_map')) {
    function cyberstore_mikado_header_standard_extended_map($parent) {
        $hide_dep_options = cyberstore_mikado_get_hide_dep_for_header_standard_extended_options();

        cyberstore_mikado_add_admin_field(
            array(
                'parent'          => $parent,
                'type'            => 'yesno',
                'name'            => 'show_extended_dropdown',
                'default_value'   => 'no',
                'label'           => esc_html__('Show Extended Dropdown', 'cyberstore'),
                'hidden_property' => 'header_type',
                'hidden_values'   => $hide_dep_options,
                'args'          => array(
                    'dependence'             => true,
                    'dependence_hide_on_yes' => '',
                    'dependence_show_on_yes' => '#mkd_extended_dropdown_container'
                )
            )
        );

        $extended_dropdown_container = cyberstore_mikado_add_admin_container(
            array(
                'parent'          => $parent,
                'name'            => 'extended_dropdown_container',
                'hidden_property' => 'show_extended_dropdown',
                'hidden_value'    => 'no',
            )
        );

        cyberstore_mikado_add_admin_field(
            array(

                'parent'        => $extended_dropdown_container,
                'type'          => 'text',
                'name'          => 'extended_dropdown_opener_label',
                'default_value' => '',
                'label'         => esc_html__( 'Extended Dropdown Opener Label', 'cyberstore' ),
                'description'   => esc_html__( 'Set Extended Dropdown Opener Label. Default value is: \'Dropdown Opener\'', 'cyberstore' ),
            )
        );

        cyberstore_mikado_add_admin_field(
            array(
                'parent'          => $extended_dropdown_container,
                'type'            => 'yesno',
                'name'            => 'extended_dropdown_always_opened',
                'default_value'   => 'yes',
                'label'           => esc_html__('Extended Dropdown - Always Opened', 'cyberstore')
            )
        );

        cyberstore_mikado_add_admin_field(
            array(
                'parent'          => $extended_dropdown_container,
                'type'            => 'color',
                'name'            => 'extended_dropdown_background_color',
                'default_value'   => '',
                'label'           => esc_html__('Background Color', 'cyberstore'),
                'description'     => esc_html__( 'Set Extended Dropdown Background Color', 'cyberstore' )
            )
        );
        cyberstore_mikado_add_admin_field(
            array(
                'parent'          => $extended_dropdown_container,
                'type'            => 'color',
                'name'            => 'extended_dropdown_text_color',
                'default_value'   => '',
                'label'           => esc_html__('Color', 'cyberstore'),
                'description'     => esc_html__( 'Set Extended Dropdown Text Color', 'cyberstore' ),
            )
        );



        cyberstore_mikado_add_admin_field(
            array(
                'parent'        => $parent,
                'type'          => 'yesno',
                'name'          => 'disable_menu_area',
                'default_value' => 'no',
                'label'         => esc_html__( 'Disable Menu Area', 'cyberstore' ),
                'description'   => esc_html__( 'Remove Menu Area in Extended Header Type', 'cyberstore' ),
                'hidden_property' => 'header_type',
                'hidden_values'   => $hide_dep_options,
            )
        );
    }

    add_action('cyberstore_mikado_header_menu_area_additional_options', 'cyberstore_mikado_header_standard_extended_map');
}