<?php

include_once MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-standard-extended/functions.php';
include_once MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-standard-extended/extended-dropdown/extended-dropdown-walker.php';
include_once MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-standard-extended/header-standard-extended.php';