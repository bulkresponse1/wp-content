<?php

if (!function_exists('cyberstore_mikado_register_header_standard_extended_type')) {
    /**
     * This function is used to register header type class for header factory file
     */
    function cyberstore_mikado_register_header_standard_extended_type($header_types) {
        $header_type = array(
            'header-standard-extended' => 'Cyberstore\Modules\Header\Types\HeaderStandardExtended'
        );

        $header_types = array_merge($header_types, $header_type);

        return $header_types;
    }
}

if (!function_exists('cyberstore_mikado_init_register_header_standard_extended_type')) {
    /**
     * This function is used to wait header-function.php file to init header object and then to init hook registration function above
     */
    function cyberstore_mikado_init_register_header_standard_extended_type() {
        add_filter('cyberstore_mikado_register_header_type_class', 'cyberstore_mikado_register_header_standard_extended_type');
    }

    add_action('cyberstore_mikado_before_header_function_init', 'cyberstore_mikado_init_register_header_standard_extended_type');
}

if (!function_exists('cyberstore_mikado_include_extended_dropdown_menu')) {
    /**
     * Registers additional menu navigation for theme
     */
    function cyberstore_mikado_include_extended_dropdown_menu($menus) {
        $menus['extended-dropdown-menu'] = esc_html__('Extended Dropdown', 'cyberstore');

        return $menus;
    }

    add_filter('cyberstore_mikado_register_headers_menu', 'cyberstore_mikado_include_extended_dropdown_menu');
}

if (!function_exists('cyberstore_mikado_get_extended_dropdown_menu')) {
    /**
     * This function is used to wait header-function.php file to init header object and then to init hook registration function above
     */
    function cyberstore_mikado_get_extended_dropdown_menu() {
        $params = array();

        $id = cyberstore_mikado_get_page_id();

        $show_extended_dropdown = cyberstore_mikado_get_meta_field_intersect('show_extended_dropdown', $id);

        if ($show_extended_dropdown == 'yes') {

            $extended_dd_always_opened = cyberstore_mikado_get_meta_field_intersect('extended_dropdown_always_opened', $id);

            //classes param
            $classes = array();
            $classes['mkd-extended-dropdown-menu'] = array('mkd-extended-dropdown-menu');

            if ($extended_dd_always_opened == 'yes') {
                $classes['mkd-extended-dropdown-menu'][] = 'mkd-dropdown-always-opened';
            }

            //background color

            $styles = array();

            $extended_dropdown_background_color = cyberstore_mikado_get_meta_field_intersect('extended_dropdown_background_color', $id);
            $extended_dropdown_text_color = cyberstore_mikado_get_meta_field_intersect('extended_dropdown_text_color', $id);

            if (!empty($extended_dropdown_background_color)) {
                $styles[] = 'background-color: ' . $extended_dropdown_background_color;
                $styles[] = 'color: ' . $extended_dropdown_text_color;
            }

            $params['styles'] = $styles;

            //opener title param
            $opener_title = cyberstore_mikado_get_meta_field_intersect('extended_dropdown_opener_label', $id);


            $params['opener_title'] = $opener_title !== '' ? $opener_title : esc_html__('Dropdown Opener', 'cyberstore');
            $params['classes'] = $classes;

            cyberstore_mikado_get_module_template_part('templates/extended-dropdown', 'header/types/header-standard-extended', '', $params);
        }
    }
}

if (!function_exists('cyberstore_mikado_get_menu_area_state')) {
    /**
     * This function is used to wait header-function.php file to init header object and then to init hook registration function above
     */
    function cyberstore_mikado_get_menu_area_state() {

        $id = cyberstore_mikado_get_page_id();

        $disable_menu_area = cyberstore_mikado_get_meta_field_intersect('disable_menu_area', $id);

        return $disable_menu_area;
    }
}

if (!function_exists('cyberstore_mikado_set_default_menu_height_for_header_standard_extended_type')) {
    /**
     * This function is used to wait header-function.php file to init header object and then to init hook registration function above
     */
    function cyberstore_mikado_set_default_menu_height_for_header_standard_extended_type() {
        $menu_height_meta = cyberstore_mikado_filter_px(cyberstore_mikado_options()->getOptionValue('menu_area_height'));
        $menu_height = !empty($menu_height_meta) ? intval($menu_height_meta) : 65;

        return $menu_height;
    }
}