<?php

if (!function_exists('cyberstore_mikado_get_hide_dep_for_header_standard_extended_meta_boxes')) {
    function cyberstore_mikado_get_hide_dep_for_header_standard_extended_meta_boxes() {
        $hide_dep_options = apply_filters('cyberstore_mikado_header_standard_extended_hide_meta_boxes', $hide_dep_options = array());

        return $hide_dep_options;
    }
}

if (!function_exists('cyberstore_mikado_header_standard_extended_meta_map')) {
    function cyberstore_mikado_header_standard_extended_meta_map($parent) {
        $hide_dep_options = cyberstore_mikado_get_hide_dep_for_header_standard_extended_meta_boxes();

        cyberstore_mikado_create_meta_box_field(
            array(
                'parent'          => $parent,
                'type'            => 'select',
                'name'            => 'mkd_show_extended_dropdown_meta',
                'default_value'   => '',
                'label'           => esc_html__('Show Extended Dropdown', 'cyberstore'),
                'options'         => array(
                    ''    => esc_html__('Default', 'cyberstore'),
                    'no'  => esc_html__('No', 'cyberstore'),
                    'yes' => esc_html__('Yes', 'cyberstore')
                ),
                'hidden_property' => 'header_type',
                'hidden_values'   => $hide_dep_options,
                'args'            => array(
                    'dependence' => true,
                    'hide'       => array(
                        ''    => '#mkd_extended_dropdown_container',
                        'no'  => '#mkd_extended_dropdown_container',
                        'yes' => ''
                    ),
                    'show'       => array(
                        ''    => '',
                        'no'  => '',
                        'yes' => '#mkd_extended_dropdown_container'
                    )
                )
            )
        );

        $extended_dropdown_container = cyberstore_mikado_add_admin_container_no_style(
            array(
                'name'            => 'extended_dropdown_container',
                'parent'          => $parent,
                'hidden_property' => 'mkd_show_extended_dropdown_meta',
                'hidden_value'    => 'no',
                'hidden_values'   => array('', 'no')
            )
        );

        cyberstore_mikado_create_meta_box_field(
            array(
                'name'          => 'mkd_extended_dropdown_opener_label_meta',
                'type'          => 'text',
                'default_value' => '',
                'label'         => esc_html__('Extended Dropdown Opener Label', 'cyberstore'),
                'description'   => esc_html__('Set Extended Dropdown Opener Label, or leave empty for default value.', 'cyberstore'),
                'parent'        => $extended_dropdown_container,
            )
        );

        cyberstore_mikado_create_meta_box_field(
            array(
                'name'          => 'mkd_extended_dropdown_always_opened_meta',
                'type'          => 'select',
                'default_value' => '',
                'label'         => esc_html__('Extended Dropdown - Always Opened', 'cyberstore'),
                'options'       => array(
                    ''    => esc_html__('Default', 'cyberstore'),
                    'no'  => esc_html__('No', 'cyberstore'),
                    'yes' => esc_html__('Yes', 'cyberstore')
                ),
                'parent'        => $extended_dropdown_container,
            )
        );

        cyberstore_mikado_create_meta_box_field(
            array(
                'name'          => 'mkd_extended_dropdown_background_color_meta',
                'type'          => 'color',
                'default_value' => '',
                'label'         => esc_html__('Background Color', 'cyberstore'),
                'parent'        => $extended_dropdown_container,
            )
        );

        cyberstore_mikado_create_meta_box_field(
            array(
                'name'          => 'mkd_extended_dropdown_text_color_meta',
                'type'          => 'color',
                'default_value' => '',
                'label'         => esc_html__('Color', 'cyberstore'),
                'parent'        => $extended_dropdown_container,
            )
        );

        cyberstore_mikado_create_meta_box_field(
            array(
                'parent'          => $parent,
                'type'            => 'select',
                'name'            => 'mkd_disable_menu_area_meta',
                'default_value'   => '',
                'label'         => esc_html__( 'Disable Menu Area', 'cyberstore' ),
                'description'   => esc_html__( 'Remove Menu Area in Extended Header Type', 'cyberstore' ),
                'options'         => array(
                    ''    => esc_html__('Default', 'cyberstore'),
                    'no'  => esc_html__('No', 'cyberstore'),
                    'yes' => esc_html__('Yes', 'cyberstore')
                ),
                'hidden_property' => 'header_type',
                'hidden_values'   => $hide_dep_options,
            )
        );
    }

    add_action('cyberstore_mikado_header_menu_area_meta_boxes_map', 'cyberstore_mikado_header_standard_extended_meta_map', 10, 1);
}