<div <?php cyberstore_mikado_class_attribute($classes['mkd-extended-dropdown-menu']); ?> <?php echo cyberstore_mikado_get_inline_style($styles); ?>>

    <div class="mkd-extended-dropdown-opener"> <?php echo esc_html($opener_title);?> </div>

    <?php

    wp_nav_menu(array(
        'menu'       => 'extended-dropdown-menu',
        'container'  => '',
        'menu_class' => 'mkd-extended-dropdown-menu',
        'fallback_cb' => 'top_navigation_fallback',
        'walker'     => new CyberstoreMikadoExtendedDropdownWalker()
    ));

    ?>
</div>