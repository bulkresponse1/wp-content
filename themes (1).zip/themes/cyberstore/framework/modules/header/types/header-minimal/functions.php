<?php

if ( ! function_exists( 'cyberstore_mikado_register_header_minimal_type' ) ) {
	/**
	 * This function is used to register header type class for header factory file
	 */
	function cyberstore_mikado_register_header_minimal_type( $header_types ) {
		$header_type = array(
			'header-minimal' => 'Cyberstore\Modules\Header\Types\HeaderMinimal'
		);
		
		$header_types = array_merge( $header_types, $header_type );
		
		return $header_types;
	}
}

if ( ! function_exists( 'cyberstore_mikado_init_register_header_minimal_type' ) ) {
	/**
	 * This function is used to wait header-function.php file to init header object and then to init hook registration function above
	 */
	function cyberstore_mikado_init_register_header_minimal_type() {
		add_filter( 'cyberstore_mikado_register_header_type_class', 'cyberstore_mikado_register_header_minimal_type' );
	}
	
	add_action( 'cyberstore_mikado_before_header_function_init', 'cyberstore_mikado_init_register_header_minimal_type' );
}

if ( ! function_exists( 'cyberstore_mikado_include_header_minimal_full_screen_menu' ) ) {
	/**
	 * Registers additional menu navigation for theme
	 */
	function cyberstore_mikado_include_header_minimal_full_screen_menu( $menus ) {
		$menus['popup-navigation'] = esc_html__( 'Full Screen Navigation', 'cyberstore' );
		
		return $menus;
	}
	
	if ( cyberstore_mikado_check_is_header_type_enabled( 'header-minimal' ) ) {
		add_filter( 'cyberstore_mikado_register_headers_menu', 'cyberstore_mikado_include_header_minimal_full_screen_menu' );
	}
}

if ( ! function_exists( 'cyberstore_mikado_register_header_minimal_full_screen_menu_widgets' ) ) {
	/**
	 * Registers additional widget areas for this header type
	 */
	function cyberstore_mikado_register_header_minimal_full_screen_menu_widgets() {
		register_sidebar(
			array(
				'id'            => 'fullscreen_menu_above',
				'name'          => esc_html__( 'Fullscreen Menu Top', 'cyberstore' ),
				'description'   => esc_html__( 'This widget area is rendered above full screen menu', 'cyberstore' ),
				'before_widget' => '<div class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<h4 class="mkd-widget-title">',
				'after_title'   => '</h4>'
			)
		);
		
		register_sidebar(
			array(
				'id'            => 'fullscreen_menu_below',
				'name'          => esc_html__( 'Fullscreen Menu Bottom', 'cyberstore' ),
				'description'   => esc_html__( 'This widget area is rendered below full screen menu', 'cyberstore' ),
				'before_widget' => '<div class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="mkd-widget-title-holder"><h4 class="mkd-widget-title">',
				'after_title'   => '</h4></div>'
			)
		);
	}
	
	if ( cyberstore_mikado_check_is_header_type_enabled( 'header-minimal' ) ) {
		add_action( 'widgets_init', 'cyberstore_mikado_register_header_minimal_full_screen_menu_widgets' );
	}
}