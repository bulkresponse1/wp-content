<?php

cyberstore_mikado_get_single_post_format_html($blog_single_type);

do_action('cyberstore_mikado_after_article_content');

?>

<div class="mkd-single-bottom-content">
    <?php
        cyberstore_mikado_get_module_template_part('templates/parts/single/single-navigation', 'blog');

        cyberstore_mikado_get_module_template_part('templates/parts/single/author-info', 'blog');

        cyberstore_mikado_get_module_template_part('templates/parts/single/related-posts', 'blog', '', $single_info_params);

        cyberstore_mikado_get_module_template_part('templates/parts/single/comments', 'blog');
    ?>
</div>