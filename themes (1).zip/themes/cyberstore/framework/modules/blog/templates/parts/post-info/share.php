<?php
$share_type = isset($share_type) ? $share_type : 'dropdown';
?>
<?php if(cyberstore_mikado_core_plugin_installed() && cyberstore_mikado_options()->getOptionValue('enable_social_share') === 'yes' && cyberstore_mikado_options()->getOptionValue('enable_social_share_on_post') === 'yes') { ?>
    <div class="mkd-blog-share">
        <?php echo do_shortcode("[mkd_social_share type='dropdown']") ?>
    </div>
<?php } ?>