<?php $author_id = esc_attr(get_the_author_meta('ID')); ?>

<div class="mkd-post-info-author">
    <div class="mkd-author-image">
        <a itemprop="url" href="<?php echo esc_url(get_author_posts_url($author_id)); ?>"
           title="<?php the_title_attribute(); ?>" target="_self">
            <?php echo cyberstore_mikado_kses_img(get_avatar($author_id, 67)); ?>
        </a>
    </div>
    <a itemprop="author" class="mkd-post-info-author-link"
       href="<?php echo esc_url(get_author_posts_url($author_id)); ?>">
        <?php the_author_meta('display_name'); ?>
    </a>
    <?php esc_html_e('in', 'cyberstore'); ?>
</div>

