<?php if(cyberstore_mikado_core_plugin_installed()) {?>
<div class="mkd-blog-like">
	<?php if( function_exists('cyberstore_mikado_get_like') ) cyberstore_mikado_get_like(); ?>
</div>
<?php } ?>