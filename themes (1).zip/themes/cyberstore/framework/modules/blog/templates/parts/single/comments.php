<?php
if(cyberstore_mikado_show_comments()){
    comments_template('', true);
}