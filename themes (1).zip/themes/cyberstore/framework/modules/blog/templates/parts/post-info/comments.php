<?php if(comments_open()) { ?>
	<div class="mkd-post-info-comments-holder">
		<a itemprop="url" class="mkd-post-info-comments" href="<?php comments_link(); ?>" target="_self">
            <span class="mkd-post-info-icon mkd-post-info-comments-icon">
                <i class="eltd-icon-dripicons dripicon dripicons-message mkd-icon-element" style=""></i>
            </span>
			<?php comments_number('0', '1', '%'); ?>
		</a>
	</div>
<?php } ?>