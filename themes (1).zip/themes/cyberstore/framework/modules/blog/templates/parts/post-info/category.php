<div class="mkd-post-info-category">
    <?php the_category(', '); ?>
</div>