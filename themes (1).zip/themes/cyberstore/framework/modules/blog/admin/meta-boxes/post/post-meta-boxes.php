<?php

/*** Post Settings ***/

if ( ! function_exists( 'cyberstore_mikado_map_post_meta' ) ) {
	function cyberstore_mikado_map_post_meta() {
		
		$post_meta_box = cyberstore_mikado_create_meta_box(
			array(
				'scope' => array( 'post' ),
				'title' => esc_html__( 'Post', 'cyberstore' ),
				'name'  => 'post-meta'
			)
		);
		
		cyberstore_mikado_create_meta_box_field(
			array(
				'name'          => 'mkd_blog_single_sidebar_layout_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Sidebar Layout', 'cyberstore' ),
				'description'   => esc_html__( 'Choose a sidebar layout for Blog single page', 'cyberstore' ),
				'default_value' => '',
				'parent'        => $post_meta_box,
				'options'       => array(
					''                 => esc_html__( 'Default', 'cyberstore' ),
					'no-sidebar'       => esc_html__( 'No Sidebar', 'cyberstore' ),
					'sidebar-33-right' => esc_html__( 'Sidebar 1/3 Right', 'cyberstore' ),
					'sidebar-25-right' => esc_html__( 'Sidebar 1/4 Right', 'cyberstore' ),
					'sidebar-33-left'  => esc_html__( 'Sidebar 1/3 Left', 'cyberstore' ),
					'sidebar-25-left'  => esc_html__( 'Sidebar 1/4 Left', 'cyberstore' )
				)
			)
		);

        cyberstore_mikado_create_meta_box_field(
            array(
                'name'    => 'mkd_blog_single_boxed_widgets_meta',
                'type'    => 'selectblank',
                'label'   => esc_html__('Boxed Widgets', 'cyberstore'),
                'parent'  => $post_meta_box,
                'options' => array(
                    'yes' => esc_html__('Yes', 'cyberstore'),
                    'no'  => esc_html__('No', 'cyberstore')
                )
            )
        );
		
		$cyberstore_custom_sidebars = cyberstore_mikado_get_custom_sidebars();
		if ( count( $cyberstore_custom_sidebars ) > 0 ) {
			cyberstore_mikado_create_meta_box_field( array(
				'name'        => 'mkd_blog_single_custom_sidebar_area_meta',
				'type'        => 'selectblank',
				'label'       => esc_html__( 'Sidebar to Display', 'cyberstore' ),
				'description' => esc_html__( 'Choose a sidebar to display on Blog single page. Default sidebar is "Sidebar"', 'cyberstore' ),
				'parent'      => $post_meta_box,
				'options'     => cyberstore_mikado_get_custom_sidebars(),
				'args' => array(
					'select2' => true
				)
			) );
		}
		
		cyberstore_mikado_create_meta_box_field(
			array(
				'name'        => 'mkd_blog_list_featured_image_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Blog List Image', 'cyberstore' ),
				'description' => esc_html__( 'Choose an Image for displaying in blog list. If not uploaded, featured image will be shown.', 'cyberstore' ),
				'parent'      => $post_meta_box
			)
		);
		
		cyberstore_mikado_create_meta_box_field(
			array(
				'name'          => 'mkd_blog_masonry_gallery_fixed_dimensions_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Dimensions for Fixed Proportion', 'cyberstore' ),
				'description'   => esc_html__( 'Choose image layout when it appears in Masonry lists in fixed proportion', 'cyberstore' ),
				'default_value' => 'default',
				'parent'        => $post_meta_box,
				'options'       => array(
					'default'            => esc_html__( 'Default', 'cyberstore' ),
					'large-width'        => esc_html__( 'Large Width', 'cyberstore' ),
					'large-height'       => esc_html__( 'Large Height', 'cyberstore' ),
					'large-width-height' => esc_html__( 'Large Width/Height', 'cyberstore' )
				)
			)
		);
		
		cyberstore_mikado_create_meta_box_field(
			array(
				'name'          => 'mkd_blog_masonry_gallery_original_dimensions_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Dimensions for Original Proportion', 'cyberstore' ),
				'description'   => esc_html__( 'Choose image layout when it appears in Masonry lists in original proportion', 'cyberstore' ),
				'default_value' => 'default',
				'parent'        => $post_meta_box,
				'options'       => array(
					'default'     => esc_html__( 'Default', 'cyberstore' ),
					'large-width' => esc_html__( 'Large Width', 'cyberstore' )
				)
			)
		);
		
		cyberstore_mikado_create_meta_box_field(
			array(
				'name'          => 'mkd_show_title_area_blog_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Show Title Area', 'cyberstore' ),
				'description'   => esc_html__( 'Enabling this option will show title area on your single post page', 'cyberstore' ),
				'parent'        => $post_meta_box,
				'options'       => cyberstore_mikado_get_yes_no_select_array()
			)
		);

		do_action('cyberstore_mikado_blog_post_meta', $post_meta_box);
	}
	
	add_action( 'cyberstore_mikado_meta_boxes_map', 'cyberstore_mikado_map_post_meta', 20 );
}
