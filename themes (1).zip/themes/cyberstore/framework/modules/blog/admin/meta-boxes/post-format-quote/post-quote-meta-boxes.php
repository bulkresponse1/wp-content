<?php

if ( ! function_exists( 'cyberstore_mikado_map_post_quote_meta' ) ) {
	function cyberstore_mikado_map_post_quote_meta() {
		$quote_post_format_meta_box = cyberstore_mikado_create_meta_box(
			array(
				'scope' => array( 'post' ),
				'title' => esc_html__( 'Quote Post Format', 'cyberstore' ),
				'name'  => 'post_format_quote_meta'
			)
		);
		
		cyberstore_mikado_create_meta_box_field(
			array(
				'name'        => 'mkd_post_quote_text_meta',
				'type'        => 'text',
				'label'       => esc_html__( 'Quote Text', 'cyberstore' ),
				'description' => esc_html__( 'Enter Quote text', 'cyberstore' ),
				'parent'      => $quote_post_format_meta_box,
			
			)
		);
		
		cyberstore_mikado_create_meta_box_field(
			array(
				'name'        => 'mkd_post_quote_author_meta',
				'type'        => 'text',
				'label'       => esc_html__( 'Quote Author', 'cyberstore' ),
				'description' => esc_html__( 'Enter Quote author', 'cyberstore' ),
				'parent'      => $quote_post_format_meta_box,
			)
		);
	}
	
	add_action( 'cyberstore_mikado_meta_boxes_map', 'cyberstore_mikado_map_post_quote_meta', 25 );
}