<li class="mkd-bl-item mkd-item-space clearfix">
	<div class="mkd-bli-inner">
		<?php if ( $post_info_image == 'yes' ) {
			cyberstore_mikado_get_module_template_part( 'templates/parts/image', 'blog', '', $params );
		} ?>
		<div class="mkd-bli-content">
			<?php cyberstore_mikado_get_module_template_part( 'templates/parts/title', 'blog', '', $params ); ?>
			<?php cyberstore_mikado_get_module_template_part( 'templates/parts/post-info/date', 'blog', '', $params ); ?>
		</div>
	</div>
</li>