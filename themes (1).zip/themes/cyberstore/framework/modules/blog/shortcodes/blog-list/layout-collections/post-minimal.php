<li class="mkd-bl-item mkd-item-space clearfix">
	<div class="mkd-bli-inner">
		<div class="mkd-bli-content">
			<?php cyberstore_mikado_get_module_template_part( 'templates/parts/title', 'blog', '', $params ); ?>
			<?php cyberstore_mikado_get_module_template_part( 'templates/parts/post-info/date', 'blog', '', $params ); ?>
		</div>
	</div>
</li>