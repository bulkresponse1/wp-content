<?php

/*** Child Theme Function  ***/

if ( ! function_exists( 'cyberstore_mikado_child_theme_enqueue_scripts' ) ) {
	function cyberstore_mikado_child_theme_enqueue_scripts() {

		$parent_style = 'cyberstore-mikado-default-style';

		wp_enqueue_style( 'cyberstore-mikado-child-style', get_stylesheet_directory_uri() . '/style.css', array( $parent_style ) );
	}

	add_action( 'wp_enqueue_scripts', 'cyberstore_mikado_child_theme_enqueue_scripts' );
}
function wc_hide_selected_terms( $terms, $taxonomies, $args ) {
    $new_terms = array();
    if ( in_array( 'product_cat', $taxonomies ) && !is_admin() && is_shop() ) {
        foreach ( $terms as $key => $term ) {
              if ( ! in_array( $term->slug, array( 'uncategorized' ) ) ) {
                $new_terms[] = $term;
              }
        }
        $terms = $new_terms;
    }
    return $terms;
}
add_filter( 'woocommerce_billing_fields', 'ts_unrequire_wc_phone_field');
function ts_unrequire_wc_phone_field( $fields ) {
$fields['billing_phone']['required'] = false;
return $fields;
}

add_action( 'wpo_wcpdf_after_order_data', 'wpo_wcpdf_customer_number', 10, 2 );
function wpo_wcpdf_customer_number ($template_type, $order) {
    ?>
    <tr class="customer-number">
        <th>Klantnummer:</th>
        <td><?php echo $order->get_user_id(); ?></td>
    </tr>
    <?php
}

/**add_action( 'woocommerce_admin_order_data_after_billing_address', 'wpdesk_vat_number_display_admin_order_meta', 10, 1 );
/**
 * Display VAT Number in order edit screen
 */
//function wpdesk_vat_number_display_admin_order_meta( $order ) {
   // echo '<p><strong>' . __( 'BTW-nummer', 'woocommerce' ) . ':</strong> ' . get_post_meta( $order->get_id(), '_vat_number', true ) . '</p>';**/


/////////////////////////////////extra feild////////////////////////////////

/**
 * @snippet       Add First & Last Name to My Account Register Form - WooCommerce
 * @how-to        Get CustomizeWoo.com FREE
 * @author        Rodolfo Melogli
 * @compatible    WC 3.9
 * @donate $9     https://businessbloomer.com/bloomer-armada/
 */
  
///////////////////////////////
// 1. ADD FIELDS
 /** 
add_action( 'woocommerce_register_form_start', 'bbloomer_add_name_woo_account_registration' );
  
function bbloomer_add_name_woo_account_registration() {
    ?>
  
    <p class="form-row form-row-first">
    <label for="reg_billing_first_name"><?php _e( 'First name', 'woocommerce' ); ?> <span class="required">*</span></label>
    <input type="text" class="input-text" name="billing_first_name" id="reg_billing_first_name" value="<?php if ( ! empty( $_POST['billing_first_name'] ) ) esc_attr_e( $_POST['billing_first_name'] ); ?>" />
    </p>
  
    <p class="form-row form-row-last">
    <label for="reg_billing_last_name"><?php _e( 'Last name', 'woocommerce' ); ?> <span class="required">*</span></label>
    <input type="text" class="input-text" name="billing_last_name" id="reg_billing_last_name" value="<?php if ( ! empty( $_POST['billing_last_name'] ) ) esc_attr_e( $_POST['billing_last_name'] ); ?>" />
    </p>
  

 <p class="form-row form-row-last">
    <label for="reg_Customer_type"><?php _e( 'Customer Type', 'woocommerce' ); ?> <span class="required">*</span></label>
	 <select  name="billing_Customer_type"  id="reg_billing_Customer_type" onchange="ShowDiv()"  style= "padding: 15px 20px; margin-top: 5px; width: 100%;">
	<option selected="selected">Choose one</option>
    <option value="Private">Private</option>
    <option value="Business">Business</option>
	 </select>
   
    </p>
    <div class="clear"></div>
   <div id="BusinessClientDiv" style="display:none">
	   <p class="form-row form-row-last">
    <label for="reg_billing_company_name"><?php _e( 'Company name', 'woocommerce' ); ?> <span class="required">*</span></label>
    <input type="text" class="input-text" name="billing_company_name" id="reg_billing_company_name" value="<?php if ( ! empty( $_POST['billing_company_name'] ) ) esc_attr_e( $_POST['billing_company_name'] ); ?>" />
    </p>
	   
	   
<p class="form-row form-row-last">
    <label for="reg_billing_tax_number"><?php _e( 'BTW', 'woocommerce' ); ?> <span class="required">*</span></label>
    <input type="text" class="input-text" name="billing_tax_number" id="reg_billing_tax_number" value="<?php if ( ! empty( $_POST['billing_tax_number'] ) ) esc_attr_e( $_POST['billing_tax_number'] ); ?>" />
    </p>	 
	   
	   <p class="form-row form-row-last">
    <label for="reg_billing_address_1"><?php _e( 'Comapny Address', 'woocommerce' ); ?> <span class="required">*</span></label>
    <input type="text" class="input-text" name="billing_address_1" id="reg_billing_address_1" value="<?php if ( ! empty( $_POST['billing_address_1'] ) ) esc_attr_e( $_POST['billing_address_1'] ); ?>" />
    </p>	
	   
	   
	     <p class="form-row form-row-last">
    <label for="reg_billing_street"><?php _e( 'Street', 'woocommerce' ); ?> <span class="required">*</span></label>
    <input type="text" class="input-text" name="billing_street" id="reg_billing_street" value="<?php if ( ! empty( $_POST['billing_street'] ) ) esc_attr_e( $_POST['billing_street'] ); ?>" />
    </p>	
	     <p class="form-row form-row-last">
    <label for="reg_billing_No"><?php _e( 'No', 'woocommerce' ); ?> <span class="required">*</span></label>
    <input type="text" class="input-text" name="billing_No" id="reg_billing_No" value="<?php if ( ! empty( $_POST['billing_No'] ) ) esc_attr_e( $_POST['billing_No'] ); ?>" />
    </p>	
	     <p class="form-row form-row-last">
    <label for="reg_billing_Bus"><?php _e( 'Bus', 'woocommerce' ); ?> <span class="required">*</span></label>
    <input type="text" class="input-text" name="billing_Bus" id="reg_billing_Bus" value="<?php if ( ! empty( $_POST['billing_Bus'] ) ) esc_attr_e( $_POST['billing_Bus'] ); ?>" />
    </p>	
	     <p class="form-row form-row-last">
    <label for="reg_billing_Postalcode"><?php _e( 'Postal Code', 'woocommerce' ); ?> <span class="required">*</span></label>
    <input type="text" class="input-text" name="billing_Postalcode" id="reg_billing_Postalcode" value="<?php if ( ! empty( $_POST['billing_Postalcode'] ) ) esc_attr_e( $_POST['billing_Postalcode'] ); ?>" />
    </p>	
	     <p class="form-row form-row-last">
    <label for="reg_billing_City"><?php _e( 'City', 'woocommerce' ); ?> <span class="required">*</span></label>
    <input type="text" class="input-text" name="billing_City" id="reg_billing_City" value="<?php if ( ! empty( $_POST['billing_City'] ) ) esc_attr_e( $_POST['billing_City'] ); ?>" />
    </p>	
	     <p class="form-row form-row-last">
    <label for="reg_billing_Country"><?php _e( 'Country', 'woocommerce' ); ?> <span class="required">*</span></label>
    <select  name="billing_Country"  id="reg_billing_Country"  style= "padding: 15px 20px; margin-top: 5px; width: 100%;">
	<option selected="selected">Choose one</option>
<option value="Afganistan">Afghanistan</option>
   <option value="Albania">Albania</option>
   <option value="Algeria">Algeria</option>
   <option value="American Samoa">American Samoa</option>
   <option value="Andorra">Andorra</option>
   <option value="Angola">Angola</option>
   <option value="Anguilla">Anguilla</option>
   <option value="Antigua & Barbuda">Antigua & Barbuda</option>
   <option value="Argentina">Argentina</option>
   <option value="Armenia">Armenia</option>
   <option value="Aruba">Aruba</option>
   <option value="Australia">Australia</option>
   <option value="Austria">Austria</option>
   <option value="Azerbaijan">Azerbaijan</option>
   <option value="Bahamas">Bahamas</option>
   <option value="Bahrain">Bahrain</option>
   <option value="Bangladesh">Bangladesh</option>
   <option value="Barbados">Barbados</option>
   <option value="Belarus">Belarus</option>
   <option value="Belgium">Belgium</option>
   <option value="Belize">Belize</option>
   <option value="Benin">Benin</option>
   <option value="Bermuda">Bermuda</option>
   <option value="Bhutan">Bhutan</option>
   <option value="Bolivia">Bolivia</option>
   <option value="Bonaire">Bonaire</option>
   <option value="Bosnia & Herzegovina">Bosnia & Herzegovina</option>
   <option value="Botswana">Botswana</option>
   <option value="Brazil">Brazil</option>
   <option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
   <option value="Brunei">Brunei</option>
   <option value="Bulgaria">Bulgaria</option>
   <option value="Burkina Faso">Burkina Faso</option>
   <option value="Burundi">Burundi</option>
   <option value="Cambodia">Cambodia</option>
   <option value="Cameroon">Cameroon</option>
   <option value="Canada">Canada</option>
   <option value="Canary Islands">Canary Islands</option>
   <option value="Cape Verde">Cape Verde</option>
   <option value="Cayman Islands">Cayman Islands</option>
   <option value="Central African Republic">Central African Republic</option>
   <option value="Chad">Chad</option>
   <option value="Channel Islands">Channel Islands</option>
   <option value="Chile">Chile</option>
   <option value="China">China</option>
   <option value="Christmas Island">Christmas Island</option>
   <option value="Cocos Island">Cocos Island</option>
   <option value="Colombia">Colombia</option>
   <option value="Comoros">Comoros</option>
   <option value="Congo">Congo</option>
   <option value="Cook Islands">Cook Islands</option>
   <option value="Costa Rica">Costa Rica</option>
   <option value="Cote DIvoire">Cote DIvoire</option>
   <option value="Croatia">Croatia</option>
   <option value="Cuba">Cuba</option>
   <option value="Curaco">Curacao</option>
   <option value="Cyprus">Cyprus</option>
   <option value="Czech Republic">Czech Republic</option>
   <option value="Denmark">Denmark</option>
   <option value="Djibouti">Djibouti</option>
   <option value="Dominica">Dominica</option>
   <option value="Dominican Republic">Dominican Republic</option>
   <option value="East Timor">East Timor</option>
   <option value="Ecuador">Ecuador</option>
   <option value="Egypt">Egypt</option>
   <option value="El Salvador">El Salvador</option>
   <option value="Equatorial Guinea">Equatorial Guinea</option>
   <option value="Eritrea">Eritrea</option>
   <option value="Estonia">Estonia</option>
   <option value="Ethiopia">Ethiopia</option>
   <option value="Falkland Islands">Falkland Islands</option>
   <option value="Faroe Islands">Faroe Islands</option>
   <option value="Fiji">Fiji</option>
   <option value="Finland">Finland</option>
   <option value="France">France</option>
   <option value="French Guiana">French Guiana</option>
   <option value="French Polynesia">French Polynesia</option>
   <option value="French Southern Ter">French Southern Ter</option>
   <option value="Gabon">Gabon</option>
   <option value="Gambia">Gambia</option>
   <option value="Georgia">Georgia</option>
   <option value="Germany">Germany</option>
   <option value="Ghana">Ghana</option>
   <option value="Gibraltar">Gibraltar</option>
   <option value="Great Britain">Great Britain</option>
   <option value="Greece">Greece</option>
   <option value="Greenland">Greenland</option>
   <option value="Grenada">Grenada</option>
   <option value="Guadeloupe">Guadeloupe</option>
   <option value="Guam">Guam</option>
   <option value="Guatemala">Guatemala</option>
   <option value="Guinea">Guinea</option>
   <option value="Guyana">Guyana</option>
   <option value="Haiti">Haiti</option>
   <option value="Hawaii">Hawaii</option>
   <option value="Honduras">Honduras</option>
   <option value="Hong Kong">Hong Kong</option>
   <option value="Hungary">Hungary</option>
   <option value="Iceland">Iceland</option>
   <option value="Indonesia">Indonesia</option>
   <option value="India">India</option>
   <option value="Iran">Iran</option>
   <option value="Iraq">Iraq</option>
   <option value="Ireland">Ireland</option>
   <option value="Isle of Man">Isle of Man</option>
   <option value="Israel">Israel</option>
   <option value="Italy">Italy</option>
   <option value="Jamaica">Jamaica</option>
   <option value="Japan">Japan</option>
   <option value="Jordan">Jordan</option>
   <option value="Kazakhstan">Kazakhstan</option>
   <option value="Kenya">Kenya</option>
   <option value="Kiribati">Kiribati</option>
   <option value="Korea North">Korea North</option>
   <option value="Korea Sout">Korea South</option>
   <option value="Kuwait">Kuwait</option>
   <option value="Kyrgyzstan">Kyrgyzstan</option>
   <option value="Laos">Laos</option>
   <option value="Latvia">Latvia</option>
   <option value="Lebanon">Lebanon</option>
   <option value="Lesotho">Lesotho</option>
   <option value="Liberia">Liberia</option>
   <option value="Libya">Libya</option>
   <option value="Liechtenstein">Liechtenstein</option>
   <option value="Lithuania">Lithuania</option>
   <option value="Luxembourg">Luxembourg</option>
   <option value="Macau">Macau</option>
   <option value="Macedonia">Macedonia</option>
   <option value="Madagascar">Madagascar</option>
   <option value="Malaysia">Malaysia</option>
   <option value="Malawi">Malawi</option>
   <option value="Maldives">Maldives</option>
   <option value="Mali">Mali</option>
   <option value="Malta">Malta</option>
   <option value="Marshall Islands">Marshall Islands</option>
   <option value="Martinique">Martinique</option>
   <option value="Mauritania">Mauritania</option>
   <option value="Mauritius">Mauritius</option>
   <option value="Mayotte">Mayotte</option>
   <option value="Mexico">Mexico</option>
   <option value="Midway Islands">Midway Islands</option>
   <option value="Moldova">Moldova</option>
   <option value="Monaco">Monaco</option>
   <option value="Mongolia">Mongolia</option>
   <option value="Montserrat">Montserrat</option>
   <option value="Morocco">Morocco</option>
   <option value="Mozambique">Mozambique</option>
   <option value="Myanmar">Myanmar</option>
   <option value="Nambia">Nambia</option>
   <option value="Nauru">Nauru</option>
   <option value="Nepal">Nepal</option>
   <option value="Netherland Antilles">Netherland Antilles</option>
   <option value="Netherlands">Netherlands (Holland, Europe)</option>
   <option value="Nevis">Nevis</option>
   <option value="New Caledonia">New Caledonia</option>
   <option value="New Zealand">New Zealand</option>
   <option value="Nicaragua">Nicaragua</option>
   <option value="Niger">Niger</option>
   <option value="Nigeria">Nigeria</option>
   <option value="Niue">Niue</option>
   <option value="Norfolk Island">Norfolk Island</option>
   <option value="Norway">Norway</option>
   <option value="Oman">Oman</option>
   <option value="Pakistan">Pakistan</option>
   <option value="Palau Island">Palau Island</option>
   <option value="Palestine">Palestine</option>
   <option value="Panama">Panama</option>
   <option value="Papua New Guinea">Papua New Guinea</option>
   <option value="Paraguay">Paraguay</option>
   <option value="Peru">Peru</option>
   <option value="Phillipines">Philippines</option>
   <option value="Pitcairn Island">Pitcairn Island</option>
   <option value="Poland">Poland</option>
   <option value="Portugal">Portugal</option>
   <option value="Puerto Rico">Puerto Rico</option>
   <option value="Qatar">Qatar</option>
   <option value="Republic of Montenegro">Republic of Montenegro</option>
   <option value="Republic of Serbia">Republic of Serbia</option>
   <option value="Reunion">Reunion</option>
   <option value="Romania">Romania</option>
   <option value="Russia">Russia</option>
   <option value="Rwanda">Rwanda</option>
   <option value="St Barthelemy">St Barthelemy</option>
   <option value="St Eustatius">St Eustatius</option>
   <option value="St Helena">St Helena</option>
   <option value="St Kitts-Nevis">St Kitts-Nevis</option>
   <option value="St Lucia">St Lucia</option>
   <option value="St Maarten">St Maarten</option>
   <option value="St Pierre & Miquelon">St Pierre & Miquelon</option>
   <option value="St Vincent & Grenadines">St Vincent & Grenadines</option>
   <option value="Saipan">Saipan</option>
   <option value="Samoa">Samoa</option>
   <option value="Samoa American">Samoa American</option>
   <option value="San Marino">San Marino</option>
   <option value="Sao Tome & Principe">Sao Tome & Principe</option>
   <option value="Saudi Arabia">Saudi Arabia</option>
   <option value="Senegal">Senegal</option>
   <option value="Seychelles">Seychelles</option>
   <option value="Sierra Leone">Sierra Leone</option>
   <option value="Singapore">Singapore</option>
   <option value="Slovakia">Slovakia</option>
   <option value="Slovenia">Slovenia</option>
   <option value="Solomon Islands">Solomon Islands</option>
   <option value="Somalia">Somalia</option>
   <option value="South Africa">South Africa</option>
   <option value="Spain">Spain</option>
   <option value="Sri Lanka">Sri Lanka</option>
   <option value="Sudan">Sudan</option>
   <option value="Suriname">Suriname</option>
   <option value="Swaziland">Swaziland</option>
   <option value="Sweden">Sweden</option>
   <option value="Switzerland">Switzerland</option>
   <option value="Syria">Syria</option>
   <option value="Tahiti">Tahiti</option>
   <option value="Taiwan">Taiwan</option>
   <option value="Tajikistan">Tajikistan</option>
   <option value="Tanzania">Tanzania</option>
   <option value="Thailand">Thailand</option>
   <option value="Togo">Togo</option>
   <option value="Tokelau">Tokelau</option>
   <option value="Tonga">Tonga</option>
   <option value="Trinidad & Tobago">Trinidad & Tobago</option>
   <option value="Tunisia">Tunisia</option>
   <option value="Turkey">Turkey</option>
   <option value="Turkmenistan">Turkmenistan</option>
   <option value="Turks & Caicos Is">Turks & Caicos Is</option>
   <option value="Tuvalu">Tuvalu</option>
   <option value="Uganda">Uganda</option>
   <option value="United Kingdom">United Kingdom</option>
   <option value="Ukraine">Ukraine</option>
   <option value="United Arab Erimates">United Arab Emirates</option>
   <option value="United States of America">United States of America</option>
   <option value="Uraguay">Uruguay</option>
   <option value="Uzbekistan">Uzbekistan</option>
   <option value="Vanuatu">Vanuatu</option>
   <option value="Vatican City State">Vatican City State</option>
   <option value="Venezuela">Venezuela</option>
   <option value="Vietnam">Vietnam</option>
   <option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
   <option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
   <option value="Wake Island">Wake Island</option>
   <option value="Wallis & Futana Is">Wallis & Futana Is</option>
   <option value="Yemen">Yemen</option>
   <option value="Zaire">Zaire</option>
   <option value="Zambia">Zambia</option>
   <option value="Zimbabwe">Zimbabwe</option>
	 </select>
    </p>	
	     	
	   
</div>
<p class="form-row form-row-last">
    <label for="reg_billing_phone"><?php _e( 'Phone', 'woocommerce' ); ?> <span class="required">*</span></label>
    <input type="text" class="input-text" name="billing_phone" id="reg_billing_phone" value="<?php if ( ! empty( $_POST['billing_phone'] ) ) esc_attr_e( $_POST['billing_phone'] ); ?>" />
    </p>
    <?php
}
  
///////////////////////////////
// 2. VALIDATE FIELDS
  
add_filter( 'woocommerce_registration_errors', 'bbloomer_validate_name_fields', 10, 3 );
  
function bbloomer_validate_name_fields( $errors, $username, $email ) {
    if ( isset( $_POST['billing_first_name'] ) && empty( $_POST['billing_first_name'] ) ) {
        $errors->add( 'billing_first_name_error', __( '<strong>Error</strong>: First name is required!', 'woocommerce' ) );
    }
    if ( isset( $_POST['billing_last_name'] ) && empty( $_POST['billing_last_name'] ) ) {
        $errors->add( 'billing_last_name_error', __( '<strong>Error</strong>: Last name is required!.', 'woocommerce' ) );
    }
	 if ( isset( $_POST['billing_Customer_type'] ) && empty( $_POST['billing_Customer_type'] ) ) {
        $errors->add( 'billing_Customer_type_error', __( '<strong>Error</strong>: Customer_type is required!.', 'woocommerce' ) );
    }
	if ( isset( $_POST['billing_company_name'] ) && empty( $_POST['billing_company_name'] ) ) {
        $errors->add( 'billing_company_name_error', __( '<strong>Error</strong>:company_name is required!.', 'woocommerce' ) );
    }
	if ( isset( $_POST['billing_tax_number'] ) && empty( $_POST['billing_tax_number'] ) ) {
        $errors->add( 'billing_tax_number_error', __( '<strong>Error</strong>:BTW is required!.', 'woocommerce' ) );
    }
	if ( isset( $_POST['billing_address_1'] ) && empty( $_POST['billing_address_1'] ) ) {
        $errors->add( 'billing_address_1_error', __( '<strong>Error</strong>:Company Address is required!.', 'woocommerce' ) );
    }
	
	
	
	if ( isset( $_POST['billing_street'] ) && empty( $_POST['billing_street'] ) ) {
        $errors->add( 'billing_street_error', __( '<strong>Error</strong>:Street is required!.', 'woocommerce' ) );
    }
	if ( isset( $_POST['billing_No'] ) && empty( $_POST['billing_No'] ) ) {
        $errors->add( 'billing_No_error', __( '<strong>Error</strong>:No is required!.', 'woocommerce' ) );
    }
	if ( isset( $_POST['billing_Bus'] ) && empty( $_POST['billing_Bus'] ) ) {
        $errors->add( 'billing_Bus_error', __( '<strong>Error</strong>:Bus is required!.', 'woocommerce' ) );
    }
	if ( isset( $_POST['billing_Postalcode'] ) && empty( $_POST['billing_Postalcode'] ) ) {
        $errors->add( 'billing_Postalcode_error', __( '<strong>Error</strong>:Postal Code is required!.', 'woocommerce' ) );
    }
	if ( isset( $_POST['billing_City'] ) && empty( $_POST['billing_City'] ) ) {
        $errors->add( 'billing_City_error', __( '<strong>Error</strong>:City Address is required!.', 'woocommerce' ) );
    }
	if ( isset( $_POST['billing_Country'] ) && empty( $_POST['billing_Country'] ) ) {
        $errors->add( 'billing_Country_error', __( '<strong>Error</strong>:Country is required!.', 'woocommerce' ) );
    }
	if ( isset( $_POST['billing_phone'] ) && empty( $_POST['billing_phone'] ) ) {
        $errors->add( 'billing_phone_error', __( '<strong>Error</strong>:Phone Address is required!.', 'woocommerce' ) );
    }
	
	
    return $errors;
}
  
///////////////////////////////
// 3. SAVE FIELDS
  
add_action( 'woocommerce_created_customer', 'bbloomer_save_name_fields' );
  
function bbloomer_save_name_fields( $customer_id ) {
    if ( isset( $_POST['billing_first_name'] ) ) {
        update_user_meta( $customer_id, 'billing_first_name', sanitize_text_field( $_POST['billing_first_name'] ) );
        update_user_meta( $customer_id, 'first_name', sanitize_text_field($_POST['billing_first_name']) );
    }
    if ( isset( $_POST['billing_last_name'] ) ) {
        update_user_meta( $customer_id, 'billing_last_name', sanitize_text_field( $_POST['billing_last_name'] ) );
        update_user_meta( $customer_id, 'last_name', sanitize_text_field($_POST['billing_last_name']) );
    }
	 if ( isset( $_POST['billing_Customer_type'] ) ) {
        update_user_meta( $customer_id, 'billing_Customer_type', sanitize_text_field( $_POST['billing_Customer_type'] ) );
        update_user_meta( $customer_id, 'Customer_type', sanitize_text_field($_POST['billing_Customer_type']) );
    }
	 if ( isset( $_POST['billing_Customer_type'] ) ) {
        update_user_meta( $customer_id, 'billing_company_name', sanitize_text_field( $_POST['billing_company_name'] ) );
        update_user_meta( $customer_id, 'company_name', sanitize_text_field($_POST['billing_company_name']) );
    }
	if ( isset( $_POST['billing_Customer_type'] ) ) {
        update_user_meta( $customer_id, 'billing_tax_number', sanitize_text_field( $_POST['billing_tax_number'] ) );
        update_user_meta( $customer_id, 'tax_number', sanitize_text_field($_POST['billing_tax_number']) );
    }
	if ( isset( $_POST['billing_address_1'] ) ) {
        update_user_meta( $customer_id, 'billing_tax_number', sanitize_text_field( $_POST['billing_address_1'] ) );
        update_user_meta( $customer_id, 'address_1', sanitize_text_field($_POST['billing_address_1']) );
    }
  
	
	
	if ( isset( $_POST['billing_street'] ) ) {
        update_user_meta( $customer_id, 'billing_street', sanitize_text_field( $_POST['billing_street'] ) );
        update_user_meta( $customer_id, 'street', sanitize_text_field($_POST['billing_street']) );
    }
	if ( isset( $_POST['billing_No'] ) ) {
        update_user_meta( $customer_id, 'billing_No', sanitize_text_field( $_POST['billing_No'] ) );
        update_user_meta( $customer_id, 'No', sanitize_text_field($_POST['billing_No']) );
    }
	if ( isset( $_POST['billing_Bus'] ) ) {
        update_user_meta( $customer_id, 'billing_Bus', sanitize_text_field( $_POST['billing_Bus'] ) );
        update_user_meta( $customer_id, 'Bus', sanitize_text_field($_POST['billing_Bus']) );
    }
	if ( isset( $_POST['billing_Postalcode'] ) ) {
        update_user_meta( $customer_id, 'billing_Postalcode', sanitize_text_field( $_POST['billing_Postalcode'] ) );
        update_user_meta( $customer_id, 'Postalcode', sanitize_text_field($_POST['billing_Postalcode']) );
    }
	if ( isset( $_POST['billing_City'] ) ) {
        update_user_meta( $customer_id, 'billing_City', sanitize_text_field( $_POST['billing_City'] ) );
        update_user_meta( $customer_id, 'City', sanitize_text_field($_POST['billing_City']) );
    }
	if ( isset( $_POST['billing_Country'] ) ) {
        update_user_meta( $customer_id, 'billing_Country', sanitize_text_field( $_POST['billing_Country'] ) );
        update_user_meta( $customer_id, 'Country', sanitize_text_field($_POST['billing_Country']) );
    }
	if ( isset( $_POST['billing_phone'] ) ) {
        update_user_meta( $customer_id, 'billing_phone', sanitize_text_field( $_POST['billing_phone'] ) );
        update_user_meta( $customer_id, 'phone', sanitize_text_field($_POST['billing_phone']) );
    }
	
}**/


////////////////////////////





